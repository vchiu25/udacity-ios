//
//  udacityResponse.swift
//  onthemap
//
//  Created by Vincent Chiu on 4/13/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation

struct UdacityResponse: Codable {
    let account: Account
    let session: Session
}

struct Account: Codable {
    let registered: Bool
    let key: Int
}

struct Session: Codable {
    let id: String
    let expiration: String
}
