//
//  CollectionViewController.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import CoreData

class CollectionViewController: UIViewController, UICollectionViewDataSource, NSFetchedResultsControllerDelegate {

  @IBOutlet weak var collectionView: UICollectionView!
  var fetchedResultsController: NSFetchedResultsController<Photo>!
  var dataController: DataController!
  var pin: Pin!

  @IBOutlet weak var testPicture: UIImageView!

  override func viewDidLoad() {
    super.viewDidLoad()
    setupFetchedResultsController()
  }



  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
  }

  override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
    fetchedResultsController = nil
  }

  fileprivate func setupFetchedResultsController() {
      let fetchRequest:NSFetchRequest<Photo> = Photo.fetchRequest()
      fetchRequest.sortDescriptors = [NSSortDescriptor(key: "pin", ascending: false)]
      fetchRequest.predicate = NSPredicate(format: "pin == %@", pin)

    fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "\(String(describing: pin))-photo")
      fetchedResultsController.delegate = self
      do {
          try fetchedResultsController.performFetch()
      } catch {
          fatalError("The fetch could not be performed: \(error.localizedDescription)")
      }
  }

  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return fetchedResultsController.sections?[section].numberOfObjects ?? 0
  }

  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let photo = fetchedResultsController.object(at: indexPath)
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCell

    // Configure cell
    cell.imageView.image = UIImage(data: (photo.file)!)
    return cell
  }

  func numberOfSections(in collectionView: UICollectionView) -> Int {
    return 1
  }
}
