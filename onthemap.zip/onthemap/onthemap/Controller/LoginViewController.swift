//
//  LoginViewController.swift
//  onthemap
//
//  Created by Vincent Chiu on 4/11/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var email: UITextField!

    @IBOutlet weak var password: UITextField!

    @IBOutlet weak var loginButton: UIButton!
    
    @IBAction func signup(_ sender: Any) {
        let url = URL(string: "https://www.udacity.com")!
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }
    
    @IBAction func login(_ sender: Any) {
        authenticate(email: email.text ?? "", password: password.text ?? "") { (success, error) in
            if success {
                self.getUserName()
                self.performSegue(withIdentifier: "completeLogin", sender: nil)
            } else {
            }
        }
    }
        
    func getUserName() {
        getUserData(user: SessionManager.shared.session!.account.key) { (data, error) in
            if let data = data {
            do {
                let decoder = JSONDecoder()
                let responseObject = try decoder.decode(UserResponse.self, from: data)
                SessionManager.shared.firstName = responseObject.first_name
                SessionManager.shared.lastName = responseObject.last_name
                print(SessionManager.shared)
            } catch {
                print(error)
                print("invalid account")
            }
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
