//
//  CollectionViewController.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import CoreData

class CollectionViewController: UIViewController, UICollectionViewDelegate {

  var dataController: DataController!
  var lat: Double!
  var lon: Double!

  override func viewDidLoad() {
    super.viewDidLoad()
        // Do any additional setup after loading the view.
    // check to see if photo exist
    // if not, fetch pictures and save to pin
  }

  func fetchPicture() {
    FlickrClient.getSearchResult(lat:22.755717647786838, lon:121.11699482549619) { (data, error) in
      if error != nil {
        print(error!)
        return
      }
    }
  }

  func savePictures(list: [Data]) {
    for data in list {
      let photo = PhotoFile(context: dataController.viewContext)
      photo.photo = data
      try? dataController.viewContext.save()
    }
  }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
