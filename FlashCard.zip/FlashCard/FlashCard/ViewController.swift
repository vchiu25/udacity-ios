//
//  ViewController.swift
//  FlashCard
//
//  Created by Vincent on 5/11/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
  }


}

