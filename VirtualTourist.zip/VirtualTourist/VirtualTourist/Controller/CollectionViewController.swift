//
//  CollectionViewController.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import CoreData

class CollectionViewController: UIViewController, UICollectionViewDataSource {

  var fetchedResultsController: NSFetchedResultsController<Photo>!
  var dataController: DataController!
  var pin: Pin!

  override func viewDidLoad() {
    super.viewDidLoad()
    // load picutres into the pin
    if (pin.photo == nil) {
      fetchPicture()
    }
    // use fetchcontroller to drive table
  }

  fileprivate func setupFetchedResultsController() {
      let fetchRequest:NSFetchRequest<Photo> = Photo.fetchRequest()
      fetchRequest.sortDescriptors = [NSSortDescriptor(key: "pin", ascending: false)]
      fetchRequest.predicate = NSPredicate(format: "pin == %@", pin)

      fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "\(pin)-photo")
      fetchedResultsController.delegate = self
      do {
          try fetchedResultsController.performFetch()
      } catch {
          fatalError("The fetch could not be performed: \(error.localizedDescription)")
      }
  }

  func fetchPicture() {
    FlickrClient.getSearchResult(pin: pin) { (list, error) in
      if error != nil {
        print(error!)
        return
      }
      self.downloadPictures(list: list!)
    }
  }

  func downloadPictures(list: [FlickrPhoto]){
    for item in list {
      guard let imageURL = URL(string: item.url_n) else {
          return
      }
      let task = URLSession.shared.dataTask(with: imageURL) { (data, response, error) in
        guard let data = data else {
          return
        }
        let photo = Photo(context: self.dataController.viewContext)
        photo.file = data
        photo.pin = self.pin
      }
      task.resume()
    }
  }
  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    //TODO
    return fetchedResultsController.sections?[section].numberOfObjects ?? 0
  }

  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    //TODO
    let photo = fetchedResultsController.object(at: indexPath)
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCell

    // Configure cell
    cell.imageView.image = UIImage(data: (photo.file)!)
    return cell
  }

  func numberOfSections(in collectionView: UICollectionView) -> Int {
    return 1
  }
}

extension CollectionViewController: NSFetchedResultsControllerDelegate {
  func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
    collectionView.endUpdates()
  }
  func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
    collectionView.beginUpdates()
  }
  func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
    switch type {
    case .delete:
      collectionView.deleteSections(IndexSet(integer: sectionIndex), with: .fade)
    case .insert:
      collectionView.insertSections(IndexSet(integer: sectionIndex), with: .fade)
    default:
      break
    }
  }
  func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
    switch type {
    case .delete:
      collectionView.deleteRows(at: [indexPath!], with: .fade)
      break
    case .insert:
      collectionView.insertRows(at: [newIndexPath!], with: .fade)
      break
    default:
      break
    }
  }
}

