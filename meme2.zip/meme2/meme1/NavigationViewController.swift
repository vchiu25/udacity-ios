//
//  NavigationViewController.swift
//  meme1
//
//  Created by Vincent Chiu on 3/7/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit

class NavigationViewController: UINavigationController {
   
    override func viewWillAppear(_ animated: Bool) {
    navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Add", style: .plain, target: self, action: #selector(addMeme))

        super.viewWillAppear(animated)
        navigationItem.title = "Sent Memes";
        navigationItem.rightBarButtonItem = UIBarButtonItem(
        title: "Make Meme",
        //image: UIImage(named: "collection_30x30"),
        style: .plain,
        target: self,
        action: #selector(addMeme))
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "Sent Memes";
        navigationItem.rightBarButtonItem = UIBarButtonItem(
        title: "Make Meme",
        //image: UIImage(named: "collection_30x30"),
        style: .plain,
        target: self,
        action: #selector(addMeme))
    }

    @objc func addMeme() {
        let controller = (storyboard?.instantiateViewController(identifier: "ViewController"))!
        present(controller, animated: true, completion: nil)
    }

}
