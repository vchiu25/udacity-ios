<img src="https://s3-us-west-1.amazonaws.com/udacity-content/degrees/catalog-images/nd003.png" alt="iOS Developer Nanodegree logo" height="70" >

# UIKit Fundamentals (continued)

![Platform iOS](https://img.shields.io/badge/nanodegree-iOS-blue.svg)

This repository contains (more) resources for Udacity's UIKit Fundamentals course.

## Overview

UIKit Fundamentals is designed as a first touchpoint to Apple's expansive UIKit framework. It includes many focused examples that demonstrate specific views, view controllers, and Apple-related paradigms.

## Setup

Generally speaking, most projects can run without any additional setup. However, consult the UIKit Fundamentals course for more information.

## Maintainers

@OwenLaRosa
