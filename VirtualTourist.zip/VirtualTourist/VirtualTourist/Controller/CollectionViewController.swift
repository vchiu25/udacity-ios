//
//  CollectionViewController.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import CoreData

protocol FRCCollectionViewDelegate: class {
  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
}

class CollectionViewController: UIViewController, UICollectionViewDelegate {

  @IBOutlet weak var noPicture: UITextView!
  @IBOutlet weak var newCollection: UIButton!
  @IBOutlet weak var collectionView: UICollectionView!
  var fetchedResultsController: NSFetchedResultsController<Photo>!
  var dataController: DataController!
  var pin: Pin!
  var numberOfPhotos = 0
  var list: [FlickrPhoto] = []
  weak var delegate: FRCCollectionViewDelegate?
  var blockOperation = BlockOperation()
  let waitingGroup = DispatchGroup()

  override func viewDidLoad() {
    super.viewDidLoad()
    collectionView.dataSource = self
    collectionView.delegate = self
    initialSetup()
  }

  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    setupFetchedResultsController()
    if pin.photo?.count == 0 {
      fetchPicture(pin: pin)
    }
  }

  override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
    fetchedResultsController = nil
  }

  func initialSetup() {
    noPicture.isHidden = true
    newCollection.isHidden = true
    collectionView.reloadData()
  }

  @IBAction func newCollection(_ sender: Any) {
    if let photos = fetchedResultsController.fetchedObjects {
      for photo in photos {
          self.dataController.viewContext.performAndWait {
              DispatchQueue.main.async {
                self.dataController.viewContext.delete(photo)
                try? self.dataController.viewContext.save()
              }
          }
      }
    }
    self.collectionView.reloadData()
    collectionView!.numberOfItems(inSection: 0)
    fetchPicture(pin: pin)
  }

  fileprivate func setupFetchedResultsController() {
      let fetchRequest:NSFetchRequest<Photo> = Photo.fetchRequest()
      fetchRequest.sortDescriptors = [NSSortDescriptor(key: "pin", ascending: false)]
      fetchRequest.predicate = NSPredicate(format: "pin == %@", pin)

    fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "\(String(describing: pin))-photo")
      fetchedResultsController.delegate = self
      do {
          try fetchedResultsController.performFetch()
      } catch {
          fatalError("The fetch could not be performed: \(error.localizedDescription)")
      }
  }

  func fetchPicture(pin: Pin) {
    initialSetup()
    FlickrClient.getSearchResult(pin: pin) { (list, error) in
      self.numberOfPhotos = list?.count ?? 0
      self.downloadPictures(list: list!, pin: pin)
      DispatchQueue.main.async {
        if list?.count == 0 {
          self.noPicture.isHidden = false
        }
        self.waitingGroup.notify(queue: .main) {
            self.newCollection.isHidden = false
        }
      }
    }
  }

  func downloadPictures(list: [FlickrPhoto], pin: Pin) {
    for item in list {
      guard let imageURL = URL(string: item.url_n) else {
          return
      }
      FlickrClient.downloadPicture(imageURL: imageURL, pin: pin, completion: downloadHandler)
    }
  }

  func downloadHandler(data: Data?, error: Error?) {
    waitingGroup.enter()
    let photo = Photo(context: self.dataController.viewContext)
    photo.file = data
    photo.pin = self.pin
    try? self.dataController.viewContext.save()
    waitingGroup.leave()
  }
}

