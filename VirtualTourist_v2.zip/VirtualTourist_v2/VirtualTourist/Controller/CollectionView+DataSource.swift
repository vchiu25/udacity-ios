import Foundation
import UIKit
import CoreData

extension CollectionViewController: UICollectionViewDataSource {

  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return numberOfPhotos
  }

  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCell
    print(indexPath.row)
    print(self.list.count)
    let item = self.list[indexPath.row]
    print(item)
    let imageURL = URL(string: item.url_n)!
    print(imageURL)
    FlickrClient.downloadPicture(imageURL: imageURL, pin: pin) { (data, error) in
      print("downloading")
      self.waitingGroup.enter()
      let photo = Photo(context: self.dataController.viewContext)
      photo.file = data
      photo.pin = self.pin
      try? self.dataController.viewContext.save()
      DispatchQueue.main.async {
        cell.imageView.image = UIImage(data: (photo.file!))
      }
      self.waitingGroup.leave()
      print("downloaded")
    }
    return cell
  }

  func numberOfSections(in collectionView: UICollectionView) -> Int {
    return 1
  }

  func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    self.dataController.viewContext.delete(self.fetchedResultsController.object(at: indexPath))
        try? self.dataController.viewContext.save()
    collectionView.deleteItems(at: [indexPath])
    list.remove(at: indexPath.row)
  }
}
