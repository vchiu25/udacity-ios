//
//  Collection+FRC.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/16/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import CoreData

extension CollectionViewController: NSFetchedResultsControllerDelegate {

  func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
    blockOperation = BlockOperation()
  }

  func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
    let sectionIndexSet = IndexSet(integer: sectionIndex)

    switch type {
    case .insert:
      blockOperation.addExecutionBlock {
        self.collectionView?.insertSections(sectionIndexSet)
      }
    case .delete:
      DispatchQueue.main.async {
        self.blockOperation.addExecutionBlock {
          self.collectionView?.deleteSections(sectionIndexSet)
        }
      }
    case .update:
      blockOperation.addExecutionBlock {
        self.collectionView?.reloadSections(sectionIndexSet)
      }
    case .move:
      assertionFailure()
      break
    }
  }

  func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
    DispatchQueue.main.async {
      switch type {
      case .insert:
        guard let newIndexPath = newIndexPath else { break }
        self.blockOperation.addExecutionBlock {
          self.collectionView?.insertItems(at: [newIndexPath])
        }
      case .delete:
        guard let indexPath = indexPath else { break }
        self.blockOperation.addExecutionBlock {
          self.collectionView?.deleteItems(at: [indexPath])
        }
      case .update:
        guard let indexPath = indexPath else { break }

        self.blockOperation.addExecutionBlock {
          self.collectionView?.reloadItems(at: [indexPath])
        }
      case .move:
        guard let indexPath = indexPath, let newIndexPath = newIndexPath else { return }

        self.blockOperation.addExecutionBlock {
          self.collectionView?.moveItem(at: indexPath, to: newIndexPath)
        }
      }
    }
  }

  func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
    DispatchQueue.main.async {
      self.collectionView?.performBatchUpdates({
        self.blockOperation.start()
        }, completion: nil)
    }
  }

}
