//
//  WordClient.swift
//  FlashCard
//
//  Created by Vincent on 5/14/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation

class WordClient {
  static func createURL(word: String) -> URLRequest {
    let headers = [
      "x-rapidapi-host": "wordsapiv1.p.rapidapi.com",
      "x-rapidapi-key": "6652207e53msh37638942156e80cp1c1c71jsn44a5bdfbca51"
    ]

    var request = URLRequest(url: NSURL(string: "https://wordsapiv1.p.rapidapi.com/words/\(word)/definitions")! as URL,
                                            cachePolicy: .useProtocolCachePolicy,
                                        timeoutInterval: 10.0)
    request.httpMethod = "GET"
    request.allHTTPHeaderFields = headers
    return request
  }
  static func getDefinition(word: String, completion: @escaping (Data?, Error?) -> Void) {
    let dataTask = URLSession.shared.dataTask(with: createURL(word: word), completionHandler: { (data, response, error) -> Void in
      if (error != nil) {
        print(error)
        return
      } else {
        completion(data, nil)
      }
    })
    dataTask.resume()
  }
}
