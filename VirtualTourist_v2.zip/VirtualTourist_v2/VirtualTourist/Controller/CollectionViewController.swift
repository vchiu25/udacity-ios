//
//  CollectionViewController.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import CoreData

protocol FRCCollectionViewDelegate: class {
  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
}

class CollectionViewController: UIViewController, UICollectionViewDelegate, NSFetchedResultsControllerDelegate {

  @IBOutlet weak var noPicture: UITextView!
  @IBOutlet weak var newCollection: UIButton!
  @IBOutlet weak var collectionView: UICollectionView!
  var fetchedResultsController: NSFetchedResultsController<Photo>!
  var dataController: DataController!
  var pin: Pin!
  var numberOfPhotos = 0
  var list: [FlickrPhoto] = []
  weak var delegate: FRCCollectionViewDelegate?
  var blockOperation = BlockOperation()
  let waitingGroup = DispatchGroup()

  override func viewDidLoad() {
    super.viewDidLoad()
    collectionView.dataSource = self
    collectionView.delegate = self
    initialSetup()
  }

  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    setupFetchedResultsController()
  }

  override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
    fetchedResultsController = nil
  }

  func initialSetup() {
    noPicture.isHidden = true
    newCollection.isHidden = false
    numberOfPhotos = 0
    FlickrClient.getSearchResult(pin: pin) { (list, error) in
      self.list = list!
      self.numberOfPhotos = list!.count
      self.collectionView.reloadData()
    }
  }

  @IBAction func newCollection(_ sender: Any) {
    fetchedResultsController.fetchedObjects?.forEach { (photo) in
      dataController.viewContext.delete(photo)
    }
    do {
      try dataController.viewContext.save()
    } catch {
      print("Unable to save context after clearing album")
    }
    initialSetup()
  }

  fileprivate func setupFetchedResultsController() {
      let fetchRequest:NSFetchRequest<Photo> = Photo.fetchRequest()
      fetchRequest.sortDescriptors = [NSSortDescriptor(key: "pin", ascending: false)]
      fetchRequest.predicate = NSPredicate(format: "pin == %@", pin)

    fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "\(String(describing: pin))-photo")
      fetchedResultsController.delegate = self
      do {
          try fetchedResultsController.performFetch()
      } catch {
          fatalError("The fetch could not be performed: \(error.localizedDescription)")
      }
  }
}
