//
//  Album.swift
//  VirtualTourist
//
//  Created by Vincent on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation
