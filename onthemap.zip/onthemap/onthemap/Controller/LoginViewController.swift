//
//  LoginViewController.swift
//  onthemap
//
//  Created by Vincent Chiu on 4/11/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    @IBAction func signup(_ sender: Any) {
        let url = URL(string: "https://www.udacity.com")!
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }
    
    @IBAction func login(_ sender: Any) {
        authenticate(email: email.text ?? "", password: password.text ?? "") { (success, error) in
            if success {
                self.getUserName()
                self.performSegue(withIdentifier: "completeLogin", sender: nil)
            } else {
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        email.delegate = self
        password.delegate = self
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    func getUserName() {
        getUserData(user: SessionManager.shared.session!.account.key) { (data, error) in
            if let data = data {
            do {
                let decoder = JSONDecoder()
                let responseObject = try decoder.decode(UserResponse.self, from: data)
                SessionManager.shared.firstName = responseObject.first_name
                SessionManager.shared.lastName = responseObject.last_name
            } catch {
                print(error)
                print("invalid account")
            }
            }
        }
    }
    
    // MARK: Textfield delegate
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if email.text == "Email" && email.isEditing {
             email.text = ""
        }
        if password.text == "Password" && password.isEditing {
            password.text = ""
        }
    }
}
