//
//  MemeTableCell.swift
//  meme1
//
//  Created by Vincent Chiu on 3/5/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation
import UIKit

class MemeTableCell: UITableViewCell {
    
}
