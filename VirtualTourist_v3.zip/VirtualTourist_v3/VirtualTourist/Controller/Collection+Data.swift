//
//  Collection+Data.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/16/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation
import UIKit

extension CollectionViewController: UICollectionViewDataSource {

  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    if downloading {
      return list.count 
    } else {
      return fetchedResultsController.fetchedObjects?.count ?? 0
    }
  }

  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCell
    cell.imageView.image = UIImage(named: "VirtualTourist_152")
    print("getting items")
    if downloading {
      print("downloading")
      waitingGroup.enter()
      let imageURL = URL(string: list[indexPath.row].url_n)!
      FlickrClient.downloadPicture(imageURL: imageURL, pin: pin) { (data, error) in
        let photo = Photo(context: self.dataController.viewContext)
        photo.file = data
        photo.pin = self.pin
        try? self.dataController.viewContext.save()
        self.waitingGroup.leave()
        DispatchQueue.main.async {
          cell.imageView.image = UIImage(data: data!)
        }
      }
    } else {
      cell.imageView.image = UIImage(data: fetchedResultsController.object(at: indexPath).file!)
    }
    waitingGroup.notify(queue: .main) {
      DispatchQueue.main.async {
        print("waiting group fired")
        self.downloading = false
        self.newCollection.isHidden = false
        self.collectionView.reloadData()
      }
    }
    return cell
  }

  func numberOfSections(in collectionView: UICollectionView) -> Int {
    return 1
  }

  func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    if downloading {
      return
    } else {
      self.dataController.viewContext.delete(self.fetchedResultsController.object(at: indexPath))
      try? self.dataController.viewContext.save()
    }
  }
}
