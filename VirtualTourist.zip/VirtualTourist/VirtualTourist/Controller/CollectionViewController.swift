//
//  CollectionViewController.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import CoreData

protocol FRCCollectionViewDelegate: class {
  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
}

class CollectionViewController: UIViewController, UICollectionViewDelegate {

  @IBOutlet weak var noPicture: UITextView!
  @IBOutlet weak var newCollection: UIButton!
  @IBOutlet weak var collectionView: UICollectionView!
  var fetchedResultsController: NSFetchedResultsController<Photo>!
  var dataController: DataController!
  var pin: Pin!
  var numberOfPhotos = 0
  var list: [FlickrPhoto] = []
  weak var delegate: FRCCollectionViewDelegate?
  private var blockOperation = BlockOperation()
  let waitingGroup = DispatchGroup()

  override func viewDidLoad() {
    super.viewDidLoad()
    collectionView.dataSource = self
    collectionView.delegate = self
    initialSetup()
  }

  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    setupFetchedResultsController()
    if pin.photo?.count == 0 {
      fetchPicture(pin: pin)
    }
  }

  override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
    fetchedResultsController = nil
  }

  func initialSetup() {
    noPicture.isHidden = true
    newCollection.isHidden = true
    collectionView.reloadData()
  }

  @IBAction func newCollection(_ sender: Any) {
    DispatchQueue.main.async {
      for p in self.pin.photo! {
        self.dataController.viewContext.delete(p as! NSManagedObject)
      }
      try? self.dataController.viewContext.save()
    }
    fetchPicture(pin: pin)
    collectionView.reloadData()
  }

  fileprivate func setupFetchedResultsController() {
      let fetchRequest:NSFetchRequest<Photo> = Photo.fetchRequest()
      fetchRequest.sortDescriptors = [NSSortDescriptor(key: "pin", ascending: false)]
      fetchRequest.predicate = NSPredicate(format: "pin == %@", pin)

    fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "\(String(describing: pin))-photo")
      fetchedResultsController.delegate = self
      do {
          try fetchedResultsController.performFetch()
      } catch {
          fatalError("The fetch could not be performed: \(error.localizedDescription)")
      }
  }

  func fetchPicture(pin: Pin) {
    initialSetup()
    FlickrClient.getSearchResult(pin: pin) { (list, error) in
      self.numberOfPhotos = list?.count ?? 0
      self.downloadPictures(list: list!, pin: pin)
      DispatchQueue.main.async {
        if list?.count == 0 {
          self.noPicture.isHidden = false
        }
        self.waitingGroup.notify(queue: .main) {
            self.newCollection.isHidden = false
        }
      }
    }
  }

  func downloadPictures(list: [FlickrPhoto], pin: Pin) {
    var max = 0
    for item in list {
      // keep max download pictures to 100
      if max == 100 {
        return
      } else {
        max += 1
      }
      guard let imageURL = URL(string: item.url_n) else {
          return
      }
      FlickrClient.downloadPicture(imageURL: imageURL, pin: pin, completion: downloadHandler)
    }
  }

  func downloadHandler(data: Data?, error: Error?) {
    waitingGroup.enter()
    let photo = Photo(context: self.dataController.viewContext)
    photo.file = data
    photo.pin = self.pin
    try? self.dataController.viewContext.save()
    waitingGroup.leave()
  }

  func showAlert(message: String) {
      let alertVC = UIAlertController(title: "Login Failed", message: message, preferredStyle: .alert)
      alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
      show(alertVC, sender: nil)
  }
}

extension CollectionViewController: UICollectionViewDataSource {

  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return numberOfPhotos
  }

  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCell

    // Configure cell
    if indexPath.row < fetchedResultsController.fetchedObjects!.count {
      let photo = fetchedResultsController.object(at: indexPath)
      cell.imageView.image = UIImage(data: (photo.file!))
    }
    return cell
  }

  func numberOfSections(in collectionView: UICollectionView) -> Int {
    return 1
  }

  func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    DispatchQueue.main.async {
      self.dataController.viewContext.delete(self.fetchedResultsController.object(at: indexPath))
      try? self.dataController.viewContext.save()
    }
  }
}

extension CollectionViewController: NSFetchedResultsControllerDelegate {

  func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
    blockOperation = BlockOperation()
  }

  func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
    let sectionIndexSet = IndexSet(integer: sectionIndex)

    switch type {
    case .insert:
      blockOperation.addExecutionBlock {
        self.collectionView?.insertSections(sectionIndexSet)
      }
    case .delete:
      DispatchQueue.main.async {
        self.blockOperation.addExecutionBlock {
          self.collectionView?.deleteSections(sectionIndexSet)
        }
      }
    case .update:
      blockOperation.addExecutionBlock {
        self.collectionView?.reloadSections(sectionIndexSet)
      }
    case .move:
      assertionFailure()
      break
    }
  }

  func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
    DispatchQueue.main.async {
      switch type {
      case .insert:
        guard let newIndexPath = newIndexPath else { break }
        self.blockOperation.addExecutionBlock {
          self.collectionView?.insertItems(at: [newIndexPath])
        }
      case .delete:
        guard let indexPath = indexPath else { break }
        self.blockOperation.addExecutionBlock {
          self.collectionView?.deleteItems(at: [indexPath])
        }
      case .update:
        guard let indexPath = indexPath else { break }

        self.blockOperation.addExecutionBlock {
          self.collectionView?.reloadItems(at: [indexPath])
        }
      case .move:
        guard let indexPath = indexPath, let newIndexPath = newIndexPath else { return }

        self.blockOperation.addExecutionBlock {
          self.collectionView?.moveItem(at: indexPath, to: newIndexPath)
        }
      }
    }
  }

  func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
    DispatchQueue.main.async {
      self.collectionView?.performBatchUpdates({
        self.blockOperation.start()
        }, completion: nil)
    }
  }

}
