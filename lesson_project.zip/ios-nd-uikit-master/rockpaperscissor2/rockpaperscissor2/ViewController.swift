//
//  ViewController.swift
//  rockpaperscissor2
//
//  Created by Vincent Chiu on 2/22/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func rock(_ sender: UIButton) {
        let controller: ResultViewController
        controller = storyboard?.instantiateViewController(withIdentifier: "ResultViewController") as! ResultViewController
        controller.userChoice = getUserShape(sender)
        present(controller, animated: true, completion: nil)
    }


    @IBAction func paper(_ sender: UIButton) {
        performSegue(withIdentifier: "play", sender: sender)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "play" {
            let controller = segue.destination as! ResultViewController
            controller.userChoice = getUserShape(sender as! UIButton)
        }
    }
    
    func getUserShape(_ sender: UIButton) -> Shape {
        // Titles are set to one of: Rock, Paper, or Scissors
        let shape = sender.title(for: UIControl.State())!
        return Shape(rawValue: shape)!
    }
}

