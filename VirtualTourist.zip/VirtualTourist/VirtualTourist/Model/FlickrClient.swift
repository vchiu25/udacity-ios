//
//  Flickr.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation

class FlickrClient {
  static let base = "https://api.flickr.com/services/rest?method=flickr.photos.search&api_key=f20ec3ffc5b6891cfc16f15f4a09c5c9&extras=url_n&format=json&safe_search=1&per_page=30&page=1&nojsoncallback=1"

  static func bbox(lat: Double, lon: Double) -> String {
    let minLat = max(lat - 0.5, -90)
    let minLon = max(lon - 0.5, -180)
    let maxLat = min(lat + 0.5, 90)
    let maxLon = min(lon + 0.5, 180)
    print("&bbox=\(minLon),\(minLat),\(maxLon),\(maxLat)")
    return "&bbox=\(minLon),\(minLat),\(maxLon),\(maxLat)"
  }

  class func getSearchResult(lat: Double, lon: Double, completion: @escaping ([FlickrPhoto]?, Error?)->Void) {
    let url = URL(string: base + "\(bbox(lat: lat,lon: lon))")!
    print(url)
    let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
      if error != nil {
        //handle error
        return
      }
      do {
        let decoder = JSONDecoder()
        print(String(data: data!, encoding: .utf8))
        let responseObject = try decoder.decode(FlickrData.self, from: data!)
        DispatchQueue.main.async {
          completion(responseObject.photos.photo, nil)
        }
      } catch {
        completion(nil, error)
        return
      }
    }
    task.resume()
  }
}
