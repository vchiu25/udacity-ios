//
//  NoteDetailsViewController.swift
//  FlashCard
//
//  Created by Vincent on 4/25/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import UIKit

class NoteDetailsViewController: UIViewController {
    /// A text view that displays a note's text
    @IBOutlet weak var textView: UITextView!

    // To keep track of number of swipe
    var swipeCount = 1

    /// The note being displayed and edited
    var note: Note!

    /// A closure that is run when the user asks to delete the current note
    var onDelete: (() -> Void)?

    /// A date formatter for the view controller's title text
    let dateFormatter: DateFormatter = {
        let df = DateFormatter()
        df.dateStyle = .medium
        return df
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        if let date = note.creationDate {
          navigationItem.title = dateFormatter.string(from: date)
        }
      let swipeGestuerRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(moveToNextItem))
      swipeGestuerRecognizer.direction = [.left, .right]
      textView.addGestureRecognizer(swipeGestuerRecognizer)
      textView.text = note.text
      textStyling()
    }

    @objc func moveToNextItem() {
      switch (swipeCount % 2) {
      case 0:
        textView.text = note.text
        textView.backgroundColor = UIColor.white
      case 1:
        textView.text = note.definition
        textView.backgroundColor = UIColor.lightGray
      default:
        print("this should not happen")
      }
      swipeCount += 1
      return
    }

    @IBAction func deleteNote(sender: Any) {
        presentDeleteNotebookAlert()
    }

    func textStyling(){
      textView.textAlignment = .center
      let fittingSize = CGSize(width: textView.bounds.width, height: CGFloat.greatestFiniteMagnitude)
      let size = textView.sizeThatFits(fittingSize)
      let topOffset = (textView.bounds.size.height - size.height * textView.zoomScale) / 2
      let positiveTopOffset = max(1, topOffset)
      textView.contentOffset.y = -positiveTopOffset

    }
}

// -----------------------------------------------------------------------------
// MARK: - Editing

extension NoteDetailsViewController {
    func presentDeleteNotebookAlert() {
        let alert = UIAlertController(title: "Delete Note", message: "Do you want to delete this note?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: deleteHandler))
        present(alert, animated: true, completion: nil)
    }

    func deleteHandler(alertAction: UIAlertAction) {
        onDelete?()
    }
}

// -----------------------------------------------------------------------------
// MARK: - UITextViewDelegate

extension NoteDetailsViewController: UITextViewDelegate {
    func textViewDidEndEditing(_ textView: UITextView) {
        note.text = textView.text
    }
}
