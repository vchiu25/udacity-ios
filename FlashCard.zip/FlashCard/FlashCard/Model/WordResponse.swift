//
//  WordResponse.swift
//  FlashCard
//
//  Created by Vincent on 5/14/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation

struct WordResponse: Decodable {
  let definitions: [Definition]
}

struct Definition: Decodable {
  let definition: String
  let partOfSpeech: String
}
