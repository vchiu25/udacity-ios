//
//  TestViewController.swift
//  meme1
//
//  Created by Vincent Chiu on 3/7/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit

// show detail for meme
class TestViewController: UIViewController, UINavigationControllerDelegate {
    @IBOutlet weak var label: UILabel!
    var meme: Meme?
    var test: String?
    
    @IBOutlet weak var image: UIImageView!

    override func viewWillAppear(_ animated: Bool) {
        image.image = meme?.memedImage
        label.text = test
    }
}
