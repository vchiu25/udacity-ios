//
//  VillainCollectionViewCell.swift
//  BondVillains
//
//  Created by Vincent Chiu on 3/5/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation
import UIKit

// MARK: - VillainCollectionViewCell: UICollectionViewCell

class VillainCollectionViewCell: UICollectionViewCell {
 
    // MARK: Outlets
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var picture: UIImageView!
    
}
