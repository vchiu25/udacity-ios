//
//  UdacityClient.swift
//  onthemap
//
//  Created by Vincent Chiu on 4/11/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation

struct SessionManager {
    enum Endpoints {
        static let base = "https://onthemap-api.udacity.com/v1/"

        case session
        case user
        case student
        
        var stringValue: String {
            switch self {
            case .session: return SessionManager.Endpoints.base + "session"
            case .user: return SessionManager.Endpoints.base + "users"
            case .student: return SessionManager.Endpoints.base + "StudentLocation" + "?limit=200&order=-updatedAt"
            }
        }
        
        var url: URL {
            return URL(string: stringValue)!
        }
    }
    var firstName: String?
    var lastName: String?
    var locations = [StudentLocation]()
    var session: UdacityResponse?
    static var shared = SessionManager()
}

func authenticate(email: String, password: String, completion: @escaping (Bool, Error?)->Void) {
    var request = URLRequest(url: SessionManager.Endpoints.session.url)
    request.httpMethod = "POST"
    request.addValue("application/json", forHTTPHeaderField: "Accept")
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.httpBody = "{\"udacity\": {\"username\": \"vchiu25@gmail.com\", \"password\": \"zzzz1111\"}}".data(using: .utf8)
    let task = URLSession.shared.dataTask(with: request) { data, response, error in
      if error != nil { // Handle error…
          return
      }
      let range = 5..<data!.count
      let newData = data?.subdata(in: range) /* subset response data! */
      print(String(data: newData!, encoding: .utf8)!)
      do {
        let decoder = JSONDecoder()
        let responseObject = try decoder.decode(UdacityResponse.self, from: newData!)
        SessionManager.shared.session = responseObject
        DispatchQueue.main.async {
            completion(true, nil)
        }
      } catch {
        DispatchQueue.main.async {
            completion(false, error)
            print(error)
        }
      }
    }
    task.resume()
}

func logout() {
    var request = URLRequest(url: SessionManager.Endpoints.session.url)
    request.httpMethod = "DELETE"
    var xsrfCookie: HTTPCookie? = nil
    let sharedCookieStorage = HTTPCookieStorage.shared
    for cookie in sharedCookieStorage.cookies! {
      if cookie.name == "XSRF-TOKEN" { xsrfCookie = cookie }
    }
    if let xsrfCookie = xsrfCookie {
      request.setValue(xsrfCookie.value, forHTTPHeaderField: "X-XSRF-TOKEN")
    }
    let session = URLSession.shared
    let task = session.dataTask(with: request) { data, response, error in
      if error != nil { // Handle error…
          return
      }
    }
    task.resume()
}

func getUserData(user: String, completion: @escaping (Data?, Error?)->Void) {
    let request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/users/9555088833")!)
    let task = URLSession.shared.dataTask(with: request) { data, response, error in
      if error != nil { // Handle error...
          return
      }
      let range = 5..<data!.count
      let newData = data?.subdata(in: range) /* subset response data! */
        DispatchQueue.main.async {
            //print(String(data: newData!, encoding: .utf8)!)
            completion(newData, nil)
        }
    }
    task.resume()
}
