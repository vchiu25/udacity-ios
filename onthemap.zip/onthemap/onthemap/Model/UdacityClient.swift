//
//  UdacityClient.swift
//  onthemap
//
//  Created by Vincent Chiu on 4/11/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation

struct SessionManager {
    enum Endpoints {
        static let base = "https://onthemap-api.udacity.com/v1/"

        case session
        case user
        case student
        
        var stringValue: String {
            switch self {
            case .session: return SessionManager.Endpoints.base + "session"
            case .user: return SessionManager.Endpoints.base + "users"
            case .student: return SessionManager.Endpoints.base + "StudentLocation" + "?limit=200&order=-updatedAt"
            }
        }
        
        var url: URL {
            return URL(string: stringValue)!
        }
    }
    var firstName: String?
    var lastName: String?
    var locations = [StudentLocation]()
    var session: UdacityResponse?
    static var shared = SessionManager()
}

func authenticate(email: String, password: String, completion: @escaping (Data?, Error?)->Void) {
    var request = URLRequest(url: SessionManager.Endpoints.session.url)
    request.httpMethod = "POST"
    request.addValue("application/json", forHTTPHeaderField: "Accept")
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    let encoder = JSONEncoder()
    do {
        request.httpBody = try encoder.encode(UdacityRequest(udacity: Credential(username: email, password: password)))
    } catch {
        print("encode failue")
    }
    let task = URLSession.shared.dataTask(with: request) { data, response, error in
      if error != nil { // Handle error…
        completion(nil, error)
      } else {
        let range = 5..<data!.count
        let newData = data?.subdata(in: range) /* subset response data! */
        print(String(data: newData!, encoding: .utf8)!)
        completion(newData, error)
      }
    }
    task.resume()
}

func getUserData(user: String, completion: @escaping (Data?, Error?)->Void) {
    let request = URLRequest(url: URL(string: "https://onthemap-api.udacity.com/v1/users/\(user)")!)
    let task = URLSession.shared.dataTask(with: request) { data, response, error in
      if error != nil { // Handle error...
          print("failed to get data")
          print(error!)
          return
      }
      let range = 5..<data!.count
      let newData = data?.subdata(in: range) /* subset response data! */
        DispatchQueue.main.async {
            //print(String(data: newData!, encoding: .utf8)!)
            completion(newData, nil)
        }
    }
    task.resume()
}

func postStudentLocation(locationRequest: StudentLocationRequest, completion: @escaping (Bool, Error?)->Void) {
    var request = URLRequest(url: SessionManager.Endpoints.student.url)
    request.httpMethod = "POST"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    let encoder = JSONEncoder()
    request.httpBody = try! encoder.encode(locationRequest)
    let session = URLSession.shared
    let task = session.dataTask(with: request) { data, response, error in
      if error != nil { // Handle error…
        DispatchQueue.main.async {
          completion(false, error)
        }
        return
      }
      //print(String(data: data!, encoding: .utf8)!)
      DispatchQueue.main.async {
        completion(true, nil)
      }
    }
    task.resume()
}

func getStudentLocation(completion: @escaping (Bool, Error?)->Void) {
    let request = URLRequest(url: SessionManager.Endpoints.student.url)
    let task = URLSession.shared.dataTask(with: request) { data, response, error in
      if error != nil { // Handle error...
        print("can't get data")
        print(error!)
        return
      }
      //print(String(data: data!, encoding: .utf8)!)
      do {
        let decoder = JSONDecoder()
        let responseObject = try decoder.decode(StudentLocationResponse.self, from: data!)
        SessionManager.shared.locations = responseObject.results
        DispatchQueue.main.async {
          completion(true, nil)
        }
      } catch {
        completion(false, error)
        return
      }
    }
    task.resume()
}
