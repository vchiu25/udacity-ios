//
//  DetailViewController.swift
//  meme1
//
//  Created by Vincent Chiu on 3/7/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
class DetailViewController: UIViewController, UINavigationControllerDelegate {
    var meme: Meme?

    @IBOutlet weak var image: UIImageView!

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
}
