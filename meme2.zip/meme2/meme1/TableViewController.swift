//
//  TableViewController.swift
//  meme1
//
//  Created by Vincent Chiu on 3/5/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit

class TableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {  
    // MARK: Table View Data Source Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return getData().count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "MemeTableCell")!
        cell.textLabel?.text = getData()[indexPath.row].topText + " " + getData()[indexPath.row].bottomText
        cell.imageView?.image = getData()[indexPath.row].memedImage
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let controller = (self.storyboard?.instantiateViewController(identifier: "TestViewController")) as! TestViewController
            controller.meme = getData()[indexPath.row]
            self.present(controller, animated: true, completion: nil)
        
    }

}
