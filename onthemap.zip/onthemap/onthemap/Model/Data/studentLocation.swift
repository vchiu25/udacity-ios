//
//  studentLocationResponse.swift
//  onthemap
//
//  Created by Vincent Chiu on 4/11/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation

struct StudentLocationResponse: Decodable {
    let results: [StudentLocation]
}

struct StudentLocationRequest: Codable {
    let uniqueKey: String
    let firstName: String
    let lastName: String
    let mapString: String
    let mediaURL: String
    let latitude: Double
    let longitude: Double
}

struct StudentLocation: Codable {
    let createdAt: String
    let firstName: String
    let lastName: String
    let latitude: Double
    let longitude: Double
    let mapString: String
    let mediaURL: String
    let objectId: String
    let uniqueKey: String
    let updatedAt: String
}
