//
//  TMDBClient.swift
//  TheMovieManager
//
//  Created by Owen LaRosa on 8/13/18.
//  Copyright © 2018 Udacity. All rights reserved.
//

import Foundation

class TMDBClient {
    
    static let apiKey = "54306ad4699f7308d633e601ce4d8457"
    
    struct Auth {
        static var accountId = 0
        static var requestToken = ""
        static var sessionId = ""
    }
    
    enum Endpoints {
        static let base = "https://api.themoviedb.org/3"
        static let apiKeyParam = "?api_key=\(TMDBClient.apiKey)"
        
        case getWatchlist
        case getFavorite
        case search(String)
        case markWatchlist
        case markFavorite
        case getRequestToken
        case login
        case getSessionID
        case webAuth
        case logout
        case posterImageUrl(String)
        
        var stringValue: String {
            switch self {
            case .posterImageUrl(let path): return "https://image.tmdb.org/t/p/w500/\(path)"
            case .getWatchlist: return Endpoints.base + "/account/\(Auth.accountId)/watchlist/movies" + Endpoints.apiKeyParam + "&session_id=\(Auth.sessionId)"
            case .getFavorite: return Endpoints.base + "/account/\(Auth.accountId)/favorite/movies" + Endpoints.apiKeyParam + "&session_id=\(Auth.sessionId)"
            case .search(let query): return Endpoints.base + "/search/movie" + Endpoints.apiKeyParam + "&query=\(query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")"
            case .markWatchlist: return Endpoints.base + "/account/\(Auth.accountId)/watchlist" + Endpoints.apiKeyParam + "&session_id=\(Auth.sessionId)"
            case .markFavorite: return Endpoints.base + "/account/\(Auth.accountId)/favorite" + Endpoints.apiKeyParam + "&session_id=\(Auth.sessionId)"
            case .getRequestToken: return Endpoints.base + "/authentication/token/new" + Endpoints.apiKeyParam
            case .login: return Endpoints.base + "/authentication/token/validate_with_login" + Endpoints.apiKeyParam
            case .getSessionID: return Endpoints.base + "/authentication/session/new" + Endpoints.apiKeyParam
            case .webAuth: return "https://www.themoviedb.org/authenticate/" + Auth.requestToken + "?redirect_to=themoviemanager:authenticate"
            case .logout: return Endpoints.base + "/authentication/session" + Endpoints.apiKeyParam
            }
        }
        
        var url: URL {
            return URL(string: stringValue)!
        }
    }
    
    class func taskForGetRequest<ResponseType:Decodable>(url: URL, response: ResponseType.Type, completion: @escaping (ResponseType?, Error?) -> Void) -> URLSessionTask {
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data else {
                DispatchQueue.main.async {
                    completion(nil, error)
                }
                return
            }
            let decoder = JSONDecoder()
            do {
                let responseObject = try decoder.decode(ResponseType.self, from: data)
                DispatchQueue.main.async {
                    completion(responseObject, nil)
                }
            } catch {
                do {
                    let errorResponse = try decoder.decode(TMDBReponse.self, from: data)
                    DispatchQueue.main.async {
                        completion(nil, errorResponse)
                    }
                } catch {
                    DispatchQueue.main.async {
                        completion(nil, error)
                    }
                }
            }
        }
        task.resume()
        return task
    }
    class func taskForPostRequest<ResponseType:Decodable, RequestType:Encodable>(url: URL, responseType: ResponseType.Type, body: RequestType, completion: @escaping (ResponseType?, Error?)->Void) {
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try! JSONEncoder().encode(body)
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            guard let data = data else {
                DispatchQueue.main.async {
                    completion(nil, error)
                }
                return
            }
            let decoder = JSONDecoder()
            do {
                let responseObject = try decoder.decode(ResponseType.self, from: data)
                DispatchQueue.main.async {
                    completion(responseObject, nil)
                }
            } catch {
                do {
                    let errorResponse = try decoder.decode(TMDBReponse.self, from: data)
                    DispatchQueue.main.async {
                        completion(nil, errorResponse)
                    }
                } catch {
                    DispatchQueue.main.async {
                        completion(nil, error)
                    }
                }
            }
        }
        task.resume()
    }

    class func downloadPosterImage(path: String, completion: @escaping (Data?, Error?)->Void){
        let task = URLSession.shared.dataTask(with: Endpoints.posterImageUrl(path).url) { (data, response, error) in
            DispatchQueue.main.async {
                completion(data, error)
            }
        }
        task.resume()
    }
    class func markWathclist(id: Int, watchlist: Bool, completion: @escaping (Bool, Error?) -> Void) {
        let body = MarkWathclist(media_type: "movie", media_id: id, watchlist: watchlist)
        let url = Endpoints.markWatchlist.url
        let responseType = TMDBReponse.self
        taskForPostRequest(url: url, responseType: responseType, body: body) { (response, error) in
            if let response = response {
                return completion(response.status_code == 1 || response.status_code == 12 || response.status_code == 13, nil)
            } else {
                return completion(false, error)
            }
        }
    }
    
    class func markFavorite(id: Int, favorite: Bool, completion: @escaping (Bool, Error?) -> Void) {
        let body = MarkFavorite(media_type: "movie", media_id: id, favorite: favorite)
        let url = Endpoints.markFavorite.url
        let responseType = TMDBReponse.self
        taskForPostRequest(url: url, responseType: responseType, body: body) { (response, error) in
            if let response = response {
                return completion(response.status_code == 1 || response.status_code == 12 || response.status_code == 13, nil)
            } else {
                return completion(false, error)
            }
        }
    }
    
    class func search(query: String, completion: @escaping ([Movie], Error?) -> Void) -> URLSessionTask {
        let task = taskForGetRequest(url: Endpoints.search(query).url, response: MovieResults.self
        ) { (response, error) in
            if let response = response {
                return completion(response.results, nil)
            } else {
                return completion([], error)
            }
        }
        return task
    }
    class func logout(completion: @escaping () -> Void) {
        var request = URLRequest(url: Endpoints.logout.url)
        request.httpMethod = "DELETE"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let body = LogoutRequest(session_id: Auth.sessionId)
        request.httpBody = try! JSONEncoder().encode(body)
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            Auth.requestToken = ""
            Auth.sessionId = ""
            completion()
        }        
        task.resume()
    }

    class func getSessionID(completion: @escaping (Bool, Error?) -> Void) {
        let body = PostSession(request_token: Auth.requestToken)
        let url = Endpoints.getSessionID.url
        let responseType = SessionResponse.self
        taskForPostRequest(url: url, responseType: responseType, body: body) { (response, error) in
            if let response = response {
                Auth.sessionId = response.session_id
                completion(true, nil)
            } else {
                completion(false, error)
            }
        }
    }

    class func login(username: String, password: String, completion: @escaping (Bool, Error?) -> Void) {
        let body = LoginRequest(username: username, password: password, request_token: Auth.requestToken)
        let url = Endpoints.login.url
        let responseType = Token.self
        taskForPostRequest(url: url, responseType: responseType, body: body) { (response, error) in
            if let response = response {
                Auth.requestToken = response.request_token
                completion(true, nil)
            } else {
                completion(false, error)
            }
        }
    }
    
    class func getRequestToken(completion: @escaping (Bool, Error?) -> Void) {
        taskForGetRequest(url: Endpoints.getRequestToken.url, response: Token.self) {
            (response, error) in
            if let response = response {
                Auth.requestToken = response.request_token
                completion(true, nil)
            } else {
                completion(false, error)
            }
        }
    }

    class func getWatchlist(completion: @escaping ([Movie], Error?) -> Void) {
        taskForGetRequest(url: Endpoints.getWatchlist.url, response: MovieResults.self) { (response, error) in
            if let response = response {
                completion(response.results, nil)
            } else {
                completion([], error)
            }
        }
    }
    
    class func getFavorite(completion: @escaping ([Movie], Error?) -> Void) {
        taskForGetRequest(url: Endpoints.getFavorite.url, response: MovieResults.self) { (response, error) in
            if let response = response {
                completion(response.results, nil)
            } else {
                completion([], error)
            }
        }
    }
}
