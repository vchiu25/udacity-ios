//
//  MapViewController.swift
//  VirtualTourist
//
//  Created by Vincent on 5/9/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import MapKit
import CoreData

class MapViewController: UIViewController, MKMapViewDelegate {

  @IBOutlet weak var mapView: MKMapView!
  let dataController = DataController(modelName: "VirtualTourist")
  var pins: [Pin] = []

  override func viewDidLoad() {
        super.viewDidLoad()
        dataController.load()
        // Do any additional setup after loading the view.
        mapView.delegate = self
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(self.createPin(sender:)))
        mapView.addGestureRecognizer(longPress)
        if UserDefaults.standard.bool(forKey: "hasLaunchedBefore") {
            print("App has launched before")
          mapView.region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(
              latitude: UserDefaults.standard.double(forKey: "latitude"),
              longitude: UserDefaults.standard.double(forKey: "longitude")),
            span: MKCoordinateSpan(
              latitudeDelta: UserDefaults.standard.double(forKey: "latitudeDelta"),
              longitudeDelta: UserDefaults.standard.double(forKey: "longitudeDelta")))
          getPins()
        } else {
            print("This is the first launch ever!")
        }
  }

  override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
    UserDefaults.standard.set(true, forKey: "hasLaunchedBefore")
    UserDefaults.standard.set(mapView.region.center.latitude, forKey: "latitude")
    UserDefaults.standard.set(mapView.region.center.longitude, forKey: "longitude")
    UserDefaults.standard.set(mapView.region.span.latitudeDelta, forKey: "latitudeDelta")
    UserDefaults.standard.set(mapView.region.span.longitudeDelta, forKey: "longitudeDelta")
    UserDefaults.standard.synchronize()
  }
  
  @objc func createPin(sender: UILongPressGestureRecognizer) {
      if sender.state != UIGestureRecognizer.State.began { return }
        let touchLocation = sender.location(in: mapView)
        let location = mapView.convert(touchLocation, toCoordinateFrom: mapView)
        print("Tapped at lat: \(location.latitude) long: \(location.longitude)")
        addPin(lat: location.latitude, lon: location.longitude)
  }

  func getPins(){
    let fetchRequest: NSFetchRequest<Pin> = Pin.fetchRequest()
    fetchRequest.sortDescriptors = [NSSortDescriptor(key: "lat", ascending: true)]
    if let result = try? dataController.viewContext.fetch(fetchRequest) {
      pins = result
      for pin in pins {
        addAnnotation(lat: pin.lat, lon: pin.lon)
      }
    }
  }

  func addAnnotation(lat: CLLocationDegrees, lon: CLLocationDegrees){
    let annotation = MKPointAnnotation()
    annotation.coordinate = CLLocationCoordinate2D(latitude: lat, longitude: lon)
    mapView.addAnnotation(annotation)
  }

  func addPin(lat: CLLocationDegrees, lon: CLLocationDegrees) {
    addAnnotation(lat: lat, lon: lon)
    let pin = Pin(context: dataController.viewContext)
    pin.lat = lat
    pin.lon = lon
    pins.append(pin)
    try? dataController.viewContext.save()
  }

  func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
    print(mapView.selectedAnnotations.first!.coordinate)
    performSegue(withIdentifier: "showCollection", sender: self)
  }

  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    let vc = segue.destination as! CollectionViewController
    vc.lat = pins.last!.lat
    vc.lon = pins.last!.lon
  }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
