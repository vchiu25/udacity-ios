//: [Previous](@previous)

import Foundation

var json = """
{
    "name": "Earth",
    "type": "rocky",
    "standardGravity": 9.81,
    "hoursInDay": 24
}
""".data(using: .utf8)!

// create a struct called "Planet" that conforms to Codable
// the struct should have properties with matching names and data types to the JSON


// create a JSON decoder


// decode the JSON into your model object and print the result



//: [Next](@next)
