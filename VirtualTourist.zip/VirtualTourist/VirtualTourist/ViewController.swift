//
//  ViewController.swift
//  VirtualTourist
//
//  Created by Vincent on 5/5/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
  }


}

