//
//  RecordSoundViewController.swift
//  Pitch
//
//  Created by Vincent on 2/16/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import AVFoundation
import UIKit

class RecordSoundViewController: UIViewController, AVAudioRecorderDelegate {

    // MARK: alert
    struct Alerts {
        static let DismissAlert = "Dismiss"
        static let RecordingError = "Recording Error"
    }
    
    // MARK: variable
    var audioRecorder: AVAudioRecorder!
    enum RecordingingState { case recording, notRecording }

    // MARK: IBOutlet
    @IBOutlet weak var recordLabel: UILabel!
    @IBOutlet weak var recordButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!

    // MARK: IBAction
    @IBAction func startRecord(_ sender: Any) {
        let dirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask, true)[0] as String
        let recordingName = "recordedVoice.wav"
        let pathArray = [dirPath, recordingName]
        let filePath = URL(string: pathArray.joined(separator: "/"))

        let session = AVAudioSession.sharedInstance()
        try! session.setCategory(AVAudioSession.Category.playAndRecord, mode: AVAudioSession.Mode.default, options: AVAudioSession.CategoryOptions.defaultToSpeaker)

        try! audioRecorder = AVAudioRecorder(url: filePath!, settings: [:])
        audioRecorder.isMeteringEnabled = true
        audioRecorder.delegate = self
        audioRecorder.prepareToRecord()
        audioRecorder.record()
    }
    
    @IBAction func stopRecord(_ sender: Any) {
        recordLabel.text = "Tap to start"
        recordButton.isEnabled = true
        stopButton.isEnabled = false
        audioRecorder.stop()
        let audioSession = AVAudioSession.sharedInstance()
        try! audioSession.setActive(false)
    }

    // MARK: delegate will trigger this segue when done recording
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if flag {
            performSegue(withIdentifier: "stopRecording", sender: audioRecorder.url)
        } else {
            showAlert(Alerts.RecordingError)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "stopRecording" {
            // get the next controller
            let PlaySoundsViewController = segue.destination as! PlaySoundsViewController
            // get sender url
            let url = sender as! URL
            // set url in the next controller to url
            PlaySoundsViewController.recordedAudioURL = url
        }
    }
    
    // MARK: configure UI
    func configureUI(_ recordingState: RecordingingState) {
        switch(recordingState) {
        case .recording:
            recordLabel.text = "Tap to stop"
            stopButton.isEnabled = true
            recordButton.isEnabled = false
        case .notRecording:
            recordLabel.text = "Tap to start"
            stopButton.isEnabled = false
            recordButton.isEnabled = true
        }
    }
    
    // MARK: show alert
    func showAlert(_ title: String) {
        let alert = UIAlertController(title: title, message: title, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: Alerts.DismissAlert, style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

