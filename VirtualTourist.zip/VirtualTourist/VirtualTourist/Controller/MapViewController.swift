//
//  MapViewController.swift
//  VirtualTourist
//
//  Created by Vincent on 5/9/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import MapKit
import CoreData

class MapViewController: UIViewController, MKMapViewDelegate {

  @IBOutlet weak var mapView: MKMapView!
  let dataController = DataController(modelName: "VirtualTourist")
  var pins: [Pin] = []
  var selectedAnnotation: MKAnnotation!

  override func viewDidLoad() {
        super.viewDidLoad()
        dataController.load()
        // Do any additional setup after loading the view.
        mapView.delegate = self
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(self.longPressHandler(sender:)))
        mapView.addGestureRecognizer(longPress)
        if UserDefaults.standard.bool(forKey: "hasLaunchedBefore") {
          mapView.region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(
              latitude: UserDefaults.standard.double(forKey: "latitude"),
              longitude: UserDefaults.standard.double(forKey: "longitude")),
            span: MKCoordinateSpan(
              latitudeDelta: UserDefaults.standard.double(forKey: "latitudeDelta"),
              longitudeDelta: UserDefaults.standard.double(forKey: "longitudeDelta")))
          loadPins()
        } else {
            print("This is the first launch ever!")
        }
  }

  override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
    UserDefaults.standard.set(true, forKey: "hasLaunchedBefore")
    UserDefaults.standard.set(mapView.region.center.latitude, forKey: "latitude")
    UserDefaults.standard.set(mapView.region.center.longitude, forKey: "longitude")
    UserDefaults.standard.set(mapView.region.span.latitudeDelta, forKey: "latitudeDelta")
    UserDefaults.standard.set(mapView.region.span.longitudeDelta, forKey: "longitudeDelta")
    UserDefaults.standard.synchronize()
  }
  
  @objc func longPressHandler(sender: UILongPressGestureRecognizer) {
      if sender.state != UIGestureRecognizer.State.began { return }
        let touchLocation = sender.location(in: mapView)
        let location = mapView.convert(touchLocation, toCoordinateFrom: mapView)
        print("Tapped at lat: \(location.latitude) long: \(location.longitude)")
        let pin = addPin(loc: location)
        addAnnotation(pin: pin)

  }

  func loadPins(){
    let fetchRequest: NSFetchRequest<Pin> = Pin.fetchRequest()
    fetchRequest.sortDescriptors = [NSSortDescriptor(key: "lat", ascending: true)]
    if let result = try? dataController.viewContext.fetch(fetchRequest) {
      pins = result
      for pin in pins {
        addAnnotation(pin: pin)
      }
    }
  }

  func addAnnotation(pin: Pin){
    let annotation = MKPointAnnotation()
    annotation.coordinate = CLLocationCoordinate2D(latitude: pin.lat, longitude: pin.lon)
    mapView.addAnnotation(annotation)
  }

  func addPin(loc: CLLocationCoordinate2D) -> Pin {
    let pin = Pin(context: dataController.viewContext)
    pin.lat = loc.latitude
    pin.lon = loc.longitude
    pins.append(pin)
    try? dataController.viewContext.save()
    fetchPicture(pin: pin)
    return pin
  }

  func findPin(loc: CLLocationCoordinate2D) -> Pin? {
    let fetchRequest: NSFetchRequest<Pin> = Pin.fetchRequest()
    fetchRequest.sortDescriptors = [NSSortDescriptor(key: "lat", ascending: true)]
    fetchRequest.predicate = NSPredicate(format: "lat == %@ AND lon == %@",
                                         NSNumber.init(value: loc.latitude),
                                         NSNumber.init(value: loc.longitude))
    if let result = try? dataController.viewContext.fetch(fetchRequest) {
      return result.first!
    } else {
      // fetched failed. this should not happen
      return nil
    }
  }

  func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
    print("selected pin at \( mapView.selectedAnnotations.first!.coordinate)")
    performSegue(withIdentifier: "showCollection", sender: self)
  }

  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    let vc = segue.destination as! CollectionViewController
    vc.pin = findPin(loc: mapView.selectedAnnotations.first!.coordinate)
    vc.dataController = dataController
  }

  func fetchPicture(pin: Pin) {
    FlickrClient.getSearchResult(pin: pin) { (list, error) in
      if error != nil {
        print(error!)
        return
      }
      self.downloadPictures(list: list!, pin: pin)
    }
  }

  func downloadPictures(list: [FlickrPhoto], pin: Pin) {
    for item in list {
      guard let imageURL = URL(string: item.url_n) else {
          return
      }
      downloadPicture(imageURL: imageURL, pin: pin, completion: downloadHandler)
    }
  }

  func downloadPicture(imageURL: URL , pin: Pin, completion: @escaping (Data?, Error?)->Void) {
    let task = URLSession.shared.dataTask(with: imageURL) { (data, response, error) in
      guard let data = data else {
        return
      }
      print("getting pictures")
      let photo = Photo(context: self.dataController.viewContext)
      photo.file = data
      photo.pin = pin
      try? self.dataController.viewContext.save()
      completion(data,error)
    }
    task.resume()
  }

  func downloadHandler(data: Data?, error: Error?) {
    print("picture downloaded")
  }

}
