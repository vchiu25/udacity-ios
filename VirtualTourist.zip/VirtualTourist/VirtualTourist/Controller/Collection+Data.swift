//
//  Collection+Data.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/16/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation
import UIKit

extension CollectionViewController: UICollectionViewDataSource {

  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return fetchedResultsController.fetchedObjects?.count ?? 0
  }

  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCell

    // Configure cell
    if indexPath.row < fetchedResultsController.fetchedObjects!.count {
      let photo = fetchedResultsController.object(at: indexPath)
      cell.imageView.image = UIImage(data: (photo.file!))
    }
    return cell
  }

  func numberOfSections(in collectionView: UICollectionView) -> Int {
    return 1
  }

  func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    DispatchQueue.main.async {
      self.dataController.viewContext.delete(self.fetchedResultsController.object(at: indexPath))
      try? self.dataController.viewContext.save()
    }
  }
}
