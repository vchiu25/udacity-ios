//
//  ConfirmationViewController.swift
//  onthemap
//
//  Created by Vincent Chiu on 4/13/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit

class ConfirmationViewController: UIViewController {

    var student: StudentLocationRequest?
    
    @IBAction func finish(_ sender: Any) {
        print(SessionManager.shared.session!.account.key)
        postStudentLocation(locationRequest: student!) { (success, error) in
            if success {
                print("submitted")
                self.startOver()
            } else {
                print("did not submit susccesfully, try again")
            }
        }
    }
    
    func startOver2() {
        if let navigationController = navigationController {
            navigationController.popToRootViewController(animated: true)
        }
    }
    @objc func startOver() {
        if let navigationController = navigationController {
            navigationController.popToRootViewController(animated: true)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
