//
//  EmojiTextFieldDelegate.swift
//  TextFields
//
//  Created by Jason on 11/11/14.
//  Copyright (c) 2014 Udacity. All rights reserved.
//

import Foundation
import UIKit

class ZipDelegate : NSObject, UITextFieldDelegate {
    
    // MARK: Properties
    
    var translations = [String : String]()
    
    // MARK: Initializer
    
    override init() {
        super.init()
    }
        
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
                // Construct the text that will be in the field if this change is accepted
        var newText = textField.text! as NSString
        print("before \(newText)")
        newText = newText.replacingCharacters(in: range, with: string) as NSString
        print(range)
        print("after \(newText)")
        if (newText.length > 5 || Int(string) == nil) {
            return false
        } else {
            return true
        }
    }
}
