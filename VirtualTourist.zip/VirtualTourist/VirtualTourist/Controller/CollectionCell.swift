//
//  CollectionCell.swift
//  VirtualTourist
//
//  Created by Vincent on 5/12/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit

class CollectionCell: UICollectionViewCell {

}
