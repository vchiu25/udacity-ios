//
//  Collection+Data.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/16/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation
import UIKit

extension CollectionViewController: UICollectionViewDataSource {

  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return fetchedResultsController.fetchedObjects?.count ?? 0
  }

  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCell
    cell.imageView.image = UIImage(named: "VirtualTourist_152")
    // Configure cell
    if let imageData = fetchedResultsController.object(at: indexPath).file {
      cell.imageView.image = UIImage(data: imageData)
    }
    return cell
  }

  func numberOfSections(in collectionView: UICollectionView) -> Int {
    return 1
  }

  func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
  self.dataController.viewContext.delete(self.fetchedResultsController.object(at: indexPath))
      try? self.dataController.viewContext.save()
  }
}
