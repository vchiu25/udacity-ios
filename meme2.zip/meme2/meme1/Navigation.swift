//
//  Navigation.swift
//  meme1
//
//  Created by Vincent on 3/7/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation
import UIKit

// add button to navigation
class Navigation: UITabBarController  {
    @IBAction func make(_ sender: Any) {
        let controller = (storyboard?.instantiateViewController(identifier: "ViewController"))!
        present(controller, animated: true, completion: nil)
    }
}
