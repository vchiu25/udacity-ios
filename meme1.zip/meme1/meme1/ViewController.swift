//
//  ViewController.swift
//  meme1
//
//  Created by Vincent on 3/1/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate {

    // MARK: outlets
    @IBOutlet weak var cameraButton: UIBarButtonItem!
    @IBOutlet weak var imagePickerView: UIImageView!
    @IBOutlet weak var sharebar: UIToolbar!
    @IBOutlet weak var toolbar: UIToolbar!
    @IBOutlet weak var top: UITextField!
    @IBOutlet weak var bottom: UITextField!
    @IBOutlet weak var shareButton: UIBarButtonItem!

    // MARK: View housekeeping tasks
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        unsubscribeFromKeyboardNotifications()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        subscribeToKeyboardNotifications()
        cameraButton.isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
        top.defaultTextAttributes = memeTextAttributes
        bottom.defaultTextAttributes = memeTextAttributes
        shareButton.isEnabled = false
    }

    func setupTextField(textField: UITextField, text: String) {
        textField.delegate = self
        textField.textAlignment = .center
        textField.text = "TOP"
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        imagePickerView.contentMode = .scaleAspectFill
        setupTextField(textField: top, text: "TOP")
        setupTextField(textField: bottom, text: "BOTTOM")
    }
    
    // MARK: Action for take picture, share and camera
    @IBAction func pickImage(_ sender: Any) {
        selectImageFrom(source: .photoLibrary)
    }

    @IBAction func takePicture(_ sender: Any) {
        selectImageFrom(source: .camera)
    }

    @IBAction func share(_ sender: Any) {
        let controller = UIActivityViewController(activityItems: [generateMemedImage()], applicationActivities: nil)
        controller.completionWithItemsHandler = { (activityType: UIActivity.ActivityType?, completed: Bool, returnedItems: [Any]?, error: Error?) -> Void in
            if completed {
                self.save()
            }
        }
        present(controller, animated: true, completion: nil)
    }
    
    // MARK: Textfield delegate
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if top.text == "TOP" && top.isEditing {
             top.text = ""
        } else if bottom.text == "BOTTOM" && bottom.isEditing {
            bottom.text = ""
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // MARK: snapshot
    func hidebar(hide: Bool) {
        if hide {
            toolbar.isHidden = true
            sharebar.isHidden = true
        } else {
            toolbar.isHidden = false
            sharebar.isHidden = false
        }
    }

    func generateMemedImage() -> UIImage {
        hidebar(hide: true)
        UIGraphicsBeginImageContext(self.view.frame.size)
        view.drawHierarchy(in: self.view.frame, afterScreenUpdates: true)
        let memedImage:UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        hidebar(hide: false)
        return memedImage
    }

    // MARK: save
    func save() {
        let _meme = Meme(topText: top.text!, bottomText: bottom.text!, originalImage: imagePickerView.image!, memedImage: generateMemedImage())
    }

    func selectImageFrom(source: UIImagePickerController.SourceType) {
        let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = source
            present(imagePicker, animated: true, completion: nil)
    }
    // MARK: image picker delegate
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.originalImage] as? UIImage {
            imagePickerView.image = image
        }
        shareButton.isEnabled = true
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    // MARK: keyboard manipulation
    @objc func keyboardWillShow(_ notification:Notification) {
        if bottom.isEditing {
            view.frame.origin.y -= getKeyboardHeight(notification)
        }
    }
    
    @objc func keyboardWillHide(_ notification:Notification) {
        view.frame.origin.y = 0 //-getKeyboardHeight(notification)
    }

    func getKeyboardHeight(_ notification:Notification) -> CGFloat {
        let userInfo = notification.userInfo
        let keyboardSize = userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue // of CGRect
        return keyboardSize.cgRectValue.height
    }
    
    func subscribeToKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }

    func unsubscribeFromKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
}

