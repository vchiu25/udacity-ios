//
//  CollectionViewController.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import CoreData

class CollectionViewController: UIViewController {

  var dataController: DataController!
  var lat: Double=22.755717647786838
  var lon: Double=121.11699482549619
  var pin: Pin!
  var photos: [Photo] = []

  override func viewDidLoad() {
    super.viewDidLoad()
    pin = findPin()!
    loadPictures(pin: pin)
  }

  @IBOutlet weak var image: UIImageView!

  // check to see if pictures already exist

  func loadPictures(pin: Pin) {
    if (pin.photo != nil) {
      // populate collection view from storage
    } else {
      fetchPicture(pin: pin)
    }
  }

  func findPin() -> Pin? {
    let fetchRequest: NSFetchRequest<Pin> = Pin.fetchRequest()
    fetchRequest.sortDescriptors = [NSSortDescriptor(key: "lat", ascending: true)]
    fetchRequest.predicate = NSPredicate(format: "lat == %@ AND lon == %@", NSNumber.init(value: lat), NSNumber.init(value: lon))
    if let result = try? dataController.viewContext.fetch(fetchRequest) {
      print("pin found")
      print(result)
      return result.first!
    } else {
      // fetched failed. this should not happen
      return nil
    }
  }

  func fetchPicture(pin: Pin) {
    FlickrClient.getSearchResult(lat: pin.lat, lon: pin.lon) { (list, error) in
      if error != nil {
        print(error!)
        return
      }
      self.downloadPictures(list: list!)
    }
  }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

  func downloadPictures(list: [FlickrPhoto]){
    for item in list {
      guard let imageURL = URL(string: item.url_n) else {
          return
      }
      let task = URLSession.shared.dataTask(with: imageURL) { (data, response, error) in
        guard let data = data else {
          return
        }
        let photo = Photo(context: self.dataController.viewContext)
        photo.file = data
        photo.pin = self.pin
        self.photos.append(photo)
        DispatchQueue.main.async {
          self.image.image = UIImage(data: data)
        }
      }
      task.resume()
    }
  }
}
/*
extension CollectionViewController: UICollectionViewDataSource {
  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    //TODO
    return []
  }

  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    //TODO
  }

  func numberOfSections(in collectionView: UICollectionView) -> Int {
    return 1
  }
}
*/
