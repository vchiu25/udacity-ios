//
//  ListDataSource.swift
//  Mooskine
//
//  Created by Vincent Chiu on 5/3/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import UIKit
import CoreData

class ListDataSource<ObjectType: NSManagedObject, CellType: UITableViewCell>: NSObject, UITableViewDataSource, NSFetchedResultsControllerDelegate {
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    <#code#>
  }

  var tableView: UITableView
  var frc: NSFetchedResultsController<ObjectType>
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return frc.sections?[section].numberOfObjects ?? 0
  }

  func numberOfSections(in tableView: UITableView) -> Int {
    if let sections = frc.sections {
      return sections.count
    } else {
      return 1
    }
  }

  init(tableView: UITableView, managedObjectContext: NSManagedObjectContext, fetchRequest: NSFetchRequest<ObjectType>, configure: @escaping (CellType, ObjectType) -> Void) {
        //
    self.tableView = tableView
    frc = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
    frc.delegate = self
    do {
      try frc.performFetch()
    } catch {
      fatalError(error.localizedDescription)
    }
  }
  func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
    tableView.beginUpdates()
  }
  func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
    tableView.endUpdates()
  }
  func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
    switch(type) {
    case .insert:
      tableView.insertRows(at: [newIndexPath!], with: .fade)
    case .delete:
      tableView.deleteRows(at: [indexPath!], with: .fade)
    default:
      break
    }
  }
}


