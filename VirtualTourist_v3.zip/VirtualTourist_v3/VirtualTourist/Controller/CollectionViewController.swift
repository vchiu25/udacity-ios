//
//  CollectionViewController.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import CoreData

protocol FRCCollectionViewDelegate: class {
  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
}

class CollectionViewController: UIViewController, UICollectionViewDelegate {

  @IBOutlet weak var noPicture: UITextView!
  @IBOutlet weak var newCollection: UIButton!
  @IBOutlet weak var collectionView: UICollectionView!
  var fetchedResultsController: NSFetchedResultsController<Photo>!
  var dataController: DataController!
  var pin: Pin!
  var list: [FlickrPhoto] = []
  weak var delegate: FRCCollectionViewDelegate?
  var blockOperation = BlockOperation()
  let waitingGroup = DispatchGroup()
  var downloading = true

  override func viewDidLoad() {
    super.viewDidLoad()
    collectionView.dataSource = self
    collectionView.delegate = self
    if pin.photo?.count == 0 {
      print("empty")
      downloading = true
      initialSetup()
    } else {
      print("not empty")
      downloading = false
      newCollection.isHidden = false
      collectionView.reloadData()
    }
    setupFetchedResultsController()
    collectionView.reloadData()
  }

  override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
    fetchedResultsController = nil
  }

  func initialSetup() {
    noPicture.isHidden = true
    newCollection.isHidden = true
    getList(pin: pin)
  }

  @IBAction func newCollection(_ sender: Any) {
    if let photos = fetchedResultsController.fetchedObjects {
      for photo in photos {
          self.dataController.viewContext.delete(photo)
          try? self.dataController.viewContext.save()
        }
      }

  }

  fileprivate func setupFetchedResultsController() {
      let fetchRequest:NSFetchRequest<Photo> = Photo.fetchRequest()
      fetchRequest.sortDescriptors = [NSSortDescriptor(key: "pin", ascending: false)]
      fetchRequest.predicate = NSPredicate(format: "pin == %@", pin)

    fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "\(String(describing: pin))-photo")
      fetchedResultsController.delegate = self
      do {
          try fetchedResultsController.performFetch()
      } catch {
          fatalError("The fetch could not be performed: \(error.localizedDescription)")
      }
  }

  func getList(pin: Pin) {
    waitingGroup.enter()
    FlickrClient.getSearchResult(pin: pin) { (list, error) in
      DispatchQueue.main.async {
        self.list = list ?? []
        if list?.count == 0 {
          self.noPicture.isHidden = false
        }
        self.collectionView.reloadData()
        self.waitingGroup.leave()
      }
    }
  }
}

