//
//  Flickr.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation

class FlickrClient {
  static let base = "https://api.flickr.com/services/rest?method=flickr.photos.search&api_key=f20ec3ffc5b6891cfc16f15f4a09c5c9&extras=url_n&format=json&safe_search=1&per_page=30&page=1&nojsoncallback=1"

  static func bbox(lat: Double, lon: Double) -> String {
    let lat1 = lat + 0.5
    let lat2 = lat - 0.5
    let lon1 = lon + 0.5
    let lon2 = lon - 0.5
    return "&bbox=\(lat1),\(lon1),\(lat2),\(lon2)"
  }

  class func getSearchResult(lat: Double, lon: Double, completion: @escaping ([FlickrPhoto]?, Error?)->Void) {

    let task = URLSession.shared.dataTask(with: URL(string: base + "\(bbox(lat: lat,lon: lon))")!) { (data, response, error) in
      if error != nil {
        //handle error
        return
      }
      do {
        let decoder = JSONDecoder()
        let responseObject = try decoder.decode(FlickrData.self, from: data!)
        DispatchQueue.main.async {
          completion(responseObject.photos.photo, nil)
        }
      } catch {
        completion(nil, error)
        return
      }
    }
    task.resume()
  }
}
