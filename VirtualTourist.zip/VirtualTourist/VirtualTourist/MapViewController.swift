//
//  MapViewController.swift
//  VirtualTourist
//
//  Created by Vincent on 5/9/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController, MKMapViewDelegate {

  @IBOutlet weak var mapView: MKMapView!

  override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        mapView.delegate = self
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(self.createPin(sender:)))
        mapView.addGestureRecognizer(longPress)
        if UserDefaults.standard.bool(forKey: "hasLaunchedBefore") {
            print("App has launched before")
          mapView.region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(
              latitude: UserDefaults.standard.double(forKey: "latitude"),
              longitude: UserDefaults.standard.double(forKey: "latitude")),
            span: MKCoordinateSpan(
              latitudeDelta: UserDefaults.standard.double(forKey: "latitudeDelta"),
              longitudeDelta: UserDefaults.standard.double(forKey: "longitudeDelta")))
        } else {
            print("This is the first launch ever!")
        }
  }

  override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
    UserDefaults.standard.set(true, forKey: "hasLaunchedBefore")
    UserDefaults.standard.set(mapView.region.center.latitude, forKey: "latitude")
    UserDefaults.standard.set(mapView.region.center.longitude, forKey: "longitude")
    UserDefaults.standard.set(mapView.region.span.latitudeDelta, forKey: "latitudeDelta")
    UserDefaults.standard.set(mapView.region.span.longitudeDelta, forKey: "longitudeDelta")
    UserDefaults.standard.synchronize()
  }
  @objc func createPin(sender: UILongPressGestureRecognizer) {
      if sender.state != UIGestureRecognizer.State.began { return }
        let touchLocation = sender.location(in: mapView)
        let locationCoordinate = mapView.convert(touchLocation, toCoordinateFrom: mapView)
        print("Tapped at lat: \(locationCoordinate.latitude) long: \(locationCoordinate.longitude)")
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
