//
//  udacityRequest.swift
//  onthemap
//
//  Created by Vincent Chiu on 4/11/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation

struct UdacityRequest: Encodable {
    let username: String
    let password: String
}

struct UdacityResponse: Codable {
    var account: Account
    let session: Session
}

struct Account: Codable {
    let registered: Bool
    var key: String
}

struct Session: Codable {
    let id: String
    let expiration: String
}

