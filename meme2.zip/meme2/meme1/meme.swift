//
//  meme.swift
//  meme1
//
//  Created by Vincent on 3/3/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation
import UIKit

// Meme related definition

// MARK: Meme text property
let memeTextAttributes: [NSAttributedString.Key: Any] = [
    NSAttributedString.Key.strokeColor: UIColor.black,
    NSAttributedString.Key.foregroundColor: UIColor.white,
    NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-CondensedBlack", size: 40)!,
    NSAttributedString.Key.strokeWidth: -3.0
]

// MARK: Meme struct
struct Meme {
  let topText: String
  let bottomText: String
  let originalImage: UIImage
  let memedImage: UIImage
}
