//
//  ConfirmationViewController.swift
//  onthemap
//
//  Created by Vincent Chiu on 4/13/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import MapKit

class ConfirmationViewController: UIViewController, MKMapViewDelegate {

    var student: StudentLocationRequest?
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var mapView: MKMapView!

    // send posting request to server for processing
    @IBAction func finish(_ sender: Any) {
        activityIndicator.startAnimating()
        OnTheMap.postStudentLocation(locationRequest: student!) { (success, error) in
            self.activityIndicator.stopAnimating()
            if success {
                self.activityIndicator.stopAnimating()
                print("submitted")
                self.startOver()
            } else {
                self.showAlert(message: "posting failed due to network issue")
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        setPin(lon: student!.longitude, lat: student!.latitude)
    }
    @objc func startOver() {
        if let navigationController = navigationController {
            navigationController.popToRootViewController(animated: true)
        }
    }
    
    // create annotation
    func setPin(lon: Double, lat: Double) {
        setMapInitialLocation(lon: lon, lat: lat)
        let coordinate = CLLocationCoordinate2D(latitude: lat, longitude: lon)
        let annotation = MKPointAnnotation()
        annotation.coordinate = coordinate
        annotation.title = student!.mapString
        mapView.addAnnotation(annotation)
    }
    
    func showAlert(message: String) {
        let alertVC = UIAlertController(title: "Submit Failed", message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertVC, animated: true, completion: nil)
    }
    
    // center map
    func setMapInitialLocation(lon: Double, lat: Double) {
        let initialLocation = CLLocationCoordinate2D(
            latitude: lat, longitude: lon)
        let region = MKCoordinateRegion(center: initialLocation, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
                mapView.setRegion(region, animated: true)
    }
}
