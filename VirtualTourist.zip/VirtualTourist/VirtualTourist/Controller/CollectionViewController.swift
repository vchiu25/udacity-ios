//
//  CollectionViewController.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import CoreData

class CollectionViewController: UIViewController, UICollectionViewDelegate {

  var dataController: DataController!
  var lat: Double=22.755717647786838
  var lon: Double=121.11699482549619
  var pin: Pin!

  override func viewDidLoad() {
    super.viewDidLoad()
    print("\(lat) \(lon)")
    fetchPicture()
    //downloadPicture()
  }

  @IBOutlet weak var image: UIImageView!

  // check to see if pictures already exist

  func findPin() -> Pin? {
    let fetchRequest: NSFetchRequest<Pin> = Pin.fetchRequest()
    fetchRequest.sortDescriptors = [NSSortDescriptor(key: "lat", ascending: true)]
    //fetchRequest.predicate = NSPredicate(format: "lat == %@ AND lon == %@", lat, lon)
    //fetchRequest.predicate = NSPredicate(format: "lat == %@", lat)
    if let result = try? dataController.viewContext.fetch(fetchRequest) {
      print("pin found")
      print(result)
      return result.first
    } else {
      return nil
    }
  }

  func fileExist(pin: Pin) -> Bool {
    if (pin.photo != nil) {
      return true
    } else {
      return false
    }
  }

  func fetchPicture() {
    FlickrClient.getSearchResult(lat: lat, lon: lon) { (data, error) in
      if error != nil {
        print(error!)
        return
      }

    }
  }

  func savePictures(list: [Data]) {
    for data in list {
      let photo = PhotoFile(context: dataController.viewContext)
      photo.photo = data
      try? dataController.viewContext.save()
    }
  }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

  func downloadPicture(){
    guard let imageURL = URL(string: "https://live.staticflickr.com//65535//49881612052_43e8ed15a7_n.jpg") else {
        return
    }
    let task = URLSession.shared.dataTask(with: imageURL) { (data, response, error) in
      guard let data = data else {
        return
      }
      DispatchQueue.main.async {
        self.image.image = UIImage(data: data)
      }
    }
    task.resume()
  }
}
