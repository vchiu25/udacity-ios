//
//  CollectionViewController.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import CoreData

protocol FRCCollectionViewDelegate: class {
  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
}

class CollectionViewController: UIViewController, UICollectionViewDelegate {

  @IBOutlet weak var noPicture: UITextView!
  @IBOutlet weak var newCollection: UIButton!
  @IBOutlet weak var collectionView: UICollectionView!
  var fetchedResultsController: NSFetchedResultsController<Photo>!
  var dataController: DataController!
  var pin: Pin!
  var list: [FlickrPhoto] = []
  weak var delegate: FRCCollectionViewDelegate?
  private var blockOperation = BlockOperation()
  let waitingGroup = DispatchGroup()

  override func viewDidLoad() {
    super.viewDidLoad()
    setupFetchedResultsController()
    collectionView.dataSource = self
    collectionView.delegate = self
    collectionView.reloadData()
  }

  override func viewWillAppear(_ animated: Bool) {
    noPicture.isHidden = true
    super.viewWillAppear(animated)
    if pin.photo?.count == 0 {
      fetchPicture(pin: pin)
    } else {
      newCollection.isHidden = false
    }
  }

  override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
    fetchedResultsController = nil
  }

  @IBAction func newCollection(_ sender: Any) {
    for p in pin.photo! {
      dataController.viewContext.delete(p as! NSManagedObject)
    }
    try? dataController.viewContext.save()
    fetchPicture(pin: pin)
    collectionView.reloadData()
  }

  fileprivate func setupFetchedResultsController() {
      let fetchRequest:NSFetchRequest<Photo> = Photo.fetchRequest()
      fetchRequest.sortDescriptors = [NSSortDescriptor(key: "pin", ascending: false)]
      fetchRequest.predicate = NSPredicate(format: "pin == %@", pin)

    fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "\(String(describing: pin))-photo")
      fetchedResultsController.delegate = self
      do {
          try fetchedResultsController.performFetch()
      } catch {
          fatalError("The fetch could not be performed: \(error.localizedDescription)")
      }
  }

  func fetchPicture(pin: Pin) {
    newCollection.isHidden = true
    FlickrClient.getSearchResult(pin: pin) { (list, error) in
      self.list = list!
      self.collectionView.reloadData()
      self.downloadPictures(list: list!, pin: pin)
      DispatchQueue.main.async {
        if list?.count == 0 {
          self.noPicture.isHidden = false
          self.waitingGroup.notify(queue: .main) {
            self.newCollection.isHidden = false
          }
        }
      }
    }
  }

  func downloadPictures(list: [FlickrPhoto], pin: Pin) {
    for item in list {
      guard let imageURL = URL(string: item.url_n) else {
          return
      }
      FlickrClient.downloadPicture(imageURL: imageURL, pin: pin, completion: downloadHandler)
    }
  }

  func downloadHandler(data: Data?, error: Error?) {
    waitingGroup.enter()
    let photo = Photo(context: self.dataController.viewContext)
    photo.file = data
    photo.pin = pin
    try? self.dataController.viewContext.save()
    waitingGroup.leave()
  }

  func showAlert(message: String) {
      let alertVC = UIAlertController(title: "Login Failed", message: message, preferredStyle: .alert)
      alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
      show(alertVC, sender: nil)
  }
}

extension CollectionViewController: UICollectionViewDataSource {

  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return fetchedResultsController.sections?[section].numberOfObjects ?? 0
  }

  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCell

    // Configure cell
    if indexPath.row < fetchedResultsController.fetchedObjects!.count {
      let photo = fetchedResultsController.object(at: indexPath)
      cell.imageView.image = UIImage(data: (photo.file!))
    }
    return cell
  }

  func numberOfSections(in collectionView: UICollectionView) -> Int {
    return 1
  }

  func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
  dataController.viewContext.delete(fetchedResultsController.object(at: indexPath))
    try? dataController.viewContext.save()
    //collectionView.deleteItems(at: [indexPath])
  }
}

extension CollectionViewController: NSFetchedResultsControllerDelegate {

  func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
    blockOperation = BlockOperation()
  }

  func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
    let sectionIndexSet = IndexSet(integer: sectionIndex)

    switch type {
    case .insert:
      blockOperation.addExecutionBlock {
        self.collectionView?.insertSections(sectionIndexSet)
      }
    case .delete:
      blockOperation.addExecutionBlock {
        self.collectionView?.deleteSections(sectionIndexSet)
      }
    case .update:
      blockOperation.addExecutionBlock {
        self.collectionView?.reloadSections(sectionIndexSet)
      }
    case .move:
      assertionFailure()
      break
    }
  }

  func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
    switch type {
    case .insert:
      guard let newIndexPath = newIndexPath else { break }

      blockOperation.addExecutionBlock {
        self.collectionView?.insertItems(at: [newIndexPath])
      }
    case .delete:
      guard let indexPath = indexPath else { break }
      blockOperation.addExecutionBlock {
        self.collectionView?.deleteItems(at: [indexPath])
      }
    case .update:
      guard let indexPath = indexPath else { break }

      blockOperation.addExecutionBlock {
        self.collectionView?.reloadItems(at: [indexPath])
      }
    case .move:
      guard let indexPath = indexPath, let newIndexPath = newIndexPath else { return }

      blockOperation.addExecutionBlock {
        self.collectionView?.moveItem(at: indexPath, to: newIndexPath)
      }
    }
  }

  func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
    collectionView?.performBatchUpdates({
      self.blockOperation.start()
      }, completion: nil)
  }

}
