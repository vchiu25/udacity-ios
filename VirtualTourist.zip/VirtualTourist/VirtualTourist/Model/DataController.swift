//
//  DataController.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation
import CoreData

class DataController {

  var container:NSPersistentContainer

  var viewContext:NSManagedObjectContext {
    return container.viewContext
  }

  init(modelName:String) {
    container = NSPersistentContainer(name: modelName)
  }
  
  func load(handler: (()->Void)?=nil) {
    container.loadPersistentStores { (storeDescription, error) in
      guard error == nil else {
        fatalError(error!.localizedDescription)
      }
      handler?()
    }
  }
}
