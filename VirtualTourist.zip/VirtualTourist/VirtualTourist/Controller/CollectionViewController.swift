//
//  CollectionViewController.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit

class CollectionViewController: UIViewController {

  override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    print("fetching")
    FlickrClient.getSearchResult(lat:22.755717647786838, lon:121.11699482549619) { (data, error) in
      print("fetched")
      if error != nil {
        print(error!)
        return
      }
      print("got pictures")
      print(data!)
    }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
