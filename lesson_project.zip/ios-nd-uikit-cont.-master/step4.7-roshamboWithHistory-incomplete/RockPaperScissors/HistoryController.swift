//
//  HistoryController.swift
//  RockPaperScissors
//
//  Created by Vincent Chiu on 3/3/20.
//  Copyright © 2020 Gabrielle Miller-Messner. All rights reserved.
//

import UIKit

class HistoryController: UIViewController, UITableViewDataSource {

    @IBAction func dismiss(_ sender: Any) {
            self.dismiss(animated: true, completion: nil)

    }
    var history: [RPSMatch]!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return history!.count
    }

    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HistoryCell")!
        let match = self.history[(indexPath as NSIndexPath).row]
        cell.textLabel?.text = victoryStatusDescription(match) + " " + match.p1.description + " vs " + match.p2.description
        return cell
    }
    
    func victoryStatusDescription(_ match: RPSMatch) -> String {
        
        if (match.p1 == match.p2) {
            return "Tie."
        } else if (match.p1.defeats(match.p2)) {
            return "Win!"
        } else {
            return "Loss."
        }
    }

}
