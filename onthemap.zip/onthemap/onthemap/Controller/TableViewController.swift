//
//  TableViewController.swift
//  onthemap
//
//  Created by Vincent Chiu on 4/12/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit

class TableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        activityIndicator.startAnimating()
        tableView.delegate = self
        tableView.dataSource = self
        // if location is empty then try to populate it. if not then just load it
        if Auth.shared.locations.isEmpty {
            OnTheMap.getStudentLocation { (success, error) in
                self.activityIndicator.stopAnimating()
                if success {
                    self.tableView.reloadData()
                } else {
                    DispatchQueue.main.async {
                        self.showAlert(message: "Unable to load data")
                    }
                }
            }
        } else {
            self.tableView.reloadData()
        }
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  Auth.shared.locations.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell")!
        let student =  Auth.shared.locations[indexPath.row]
               cell.textLabel?.text = student.firstName + " " + student.lastName
               cell.detailTextLabel?.text = student.mediaURL
               cell.imageView?.image = UIImage(named: "icon_pin.png")
               return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let student =  Auth.shared.locations[indexPath.row]
        let url = URL(string: student.mediaURL)
        if let url = url {
            if UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            } else {
                print("invalid url")
            }
        }
    }
    
    func showAlert(message: String) {
        let alertVC = UIAlertController(title: "Data loading Failed", message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        show(alertVC, sender: nil)
    }
}
