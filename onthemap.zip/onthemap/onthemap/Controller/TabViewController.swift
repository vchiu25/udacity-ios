//
//  Navigation.swift
//  meme1
//
//  Created by Vincent on 3/7/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation
import UIKit

// add button to navigation
class TabViewController: UITabBarController  {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadData()
    }

    @IBAction func logout(_ sender: Any) {
        OnTheMap.logout { (success, error) in
            if success {
                self.dismiss(animated: true, completion: nil)
            }
        }
    }
    @IBAction func refresh(_ sender: Any) {
        loadData()
    }
    
    func loadData() {
        OnTheMap.getStudentLocation { (success, error) in
            if success {
                return
            } else {
                print("unable to load data")
            }
        }
    }
}
