//
//  CollectionViewController.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import CoreData

class CollectionViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, NSFetchedResultsControllerDelegate {

  @IBOutlet weak var newCollection: UIButton!
  @IBOutlet weak var collectionView: UICollectionView!
  var fetchedResultsController: NSFetchedResultsController<Photo>!
  var dataController: DataController!
  var pin: Pin!
  var list: [FlickrPhoto] = []

  @IBOutlet weak var testPicture: UIImageView!

  override func viewDidLoad() {
    super.viewDidLoad()
    setupFetchedResultsController()
    collectionView.dataSource = self
    collectionView.delegate = self
    collectionView.reloadData()
  }

  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    if pin.photo?.count == 0 {
      fetchPicture(pin: pin)
    }
    newCollection.isHidden = true
  }

  override func viewWillDisappear(_ animated: Bool) {
    super.viewWillDisappear(animated)
    fetchedResultsController = nil
  }

  @IBAction func newCollection(_ sender: Any) {
    for p in pin.photo! {
      dataController.viewContext.delete(p as! NSManagedObject)
    }
    try? dataController.viewContext.save()
    fetchPicture(pin: pin)
  }

  fileprivate func setupFetchedResultsController() {
      let fetchRequest:NSFetchRequest<Photo> = Photo.fetchRequest()
      fetchRequest.sortDescriptors = [NSSortDescriptor(key: "pin", ascending: false)]
      fetchRequest.predicate = NSPredicate(format: "pin == %@", pin)

    fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "\(String(describing: pin))-photo")
      fetchedResultsController.delegate = self
      do {
          try fetchedResultsController.performFetch()
      } catch {
          fatalError("The fetch could not be performed: \(error.localizedDescription)")
      }
  }

  func fetchPicture(pin: Pin) {
    FlickrClient.getSearchResult(pin: pin) { (list, error) in
      if error != nil {
        print(error!)
        return
      }
      self.collectionView.reloadData()
      self.downloadPictures(list: list!, pin: pin)
    }
  }

  func downloadPictures(list: [FlickrPhoto], pin: Pin) {
    for item in list {
      guard let imageURL = URL(string: item.url_n) else {
          return
      }
      FlickrClient.downloadPicture(imageURL: imageURL, pin: pin, completion: downloadHandler)
    }
  }

  func downloadHandler(data: Data?, error: Error?) {
    let photo = Photo(context: self.dataController.viewContext)
    photo.file = data
    photo.pin = pin
    try? self.dataController.viewContext.save()
  }

  func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return fetchedResultsController.sections?[section].numberOfObjects ?? list.count
  }

  func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let photo = fetchedResultsController.object(at: indexPath)
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCell

    // Configure cell
    cell.imageView.image = UIImage(data: (photo.file)!)
    return cell
  }

  func numberOfSections(in collectionView: UICollectionView) -> Int {
    return 1
  }

  func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    dataController.viewContext.delete(fetchedResultsController.object(at: indexPath))
    try? dataController.viewContext.save()
    collectionView.deleteItems(at: [indexPath])
  }
}
