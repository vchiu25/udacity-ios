//
//  FlickrResponse.swift
//  VirtualTourist
//
//  Created by Vincent on 5/11/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation

struct FlickrData: Decodable {
  let photos: FlickrPhotos
}

struct FlickrPhotos: Decodable {
  let photo: [FlickrPhoto]
}

struct FlickrPhoto: Decodable {
  let url_n: String
}
