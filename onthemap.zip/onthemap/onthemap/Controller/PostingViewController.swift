//
//  PostingViewController.swift
//  onthemap
//
//  Created by Vincent Chiu on 4/12/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import MapKit

class PostingViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    var student: StudentLocationRequest?
    @IBOutlet weak var location: UITextField!
    @IBOutlet weak var link: UITextField!
    
    // MARK: Find location
    @IBAction func findLocation(_ sender: Any) {
        activityIndicator.startAnimating()
        if link.text == "Link" || link.text == "" {
            showAlert(message: "Link is empty") 
        }
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(location.text ?? "") { (clplacemarks, error) in
            self.activityIndicator.stopAnimating()
            if let clplacemark = clplacemarks?.first {
                self.populateStudentLocationRequest(clplacemark: clplacemark)
            } else {
                self.showAlert(message: "Geocoding failed - no place found")
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        location.delegate = self
        link.delegate = self
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    // MARK: Create Request
    func populateStudentLocationRequest(clplacemark: CLPlacemark) {
        getUserData(user: SessionManager.shared.session!.session.id) { (data, error) in
            if error == nil {
                let request = StudentLocationRequest(
                    uniqueKey: SessionManager.shared.session!.account.key,
                    firstName: SessionManager.shared.firstName!,
                    lastName: SessionManager.shared.lastName!,
                    mapString: self.location.text!,
                    mediaURL: self.link.text!,
                    latitude: clplacemark.location!.coordinate.latitude,
                    longitude: clplacemark.location!.coordinate.longitude)
                self.student = request
                self.performSegue(withIdentifier: "confirmation", sender: nil)
            } else {
                print("can't create student location request")
                print(error!)
            }
        }
    }
    
    // MARK: Segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! ConfirmationViewController
        vc.student = self.student
    }
    
    // MARK: Textfield delegate
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if location.text == "Location" && location.isEditing {
             location.text = ""
        }
        if link.text == "Link" && link.isEditing {
            link.text = ""
        }
    }
    
    func showAlert(message: String) {
        let alertVC = UIAlertController(title: "Posting Failure", message: message, preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        show(alertVC, sender: nil)
    }
}
