//
//  VillainDetailViewController.swift
//  BondVillains
//
//  Created by Vincent Chiu on 3/4/20.
//  Copyright © 2020 Udacity. All rights reserved.
//

import UIKit

class VillainDetailViewController: UIViewController {

    var villain: Villain!
    
    @IBOutlet weak var labe: UILabel!
    @IBOutlet weak var imageview: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        labe.text = villain.name
        imageview.image = UIImage(named: villain.imageName)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
