//
//  ResultViewController.swift
//  rockpaperscissor2
//
//  Created by Vincent Chiu on 2/22/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
enum Shape: String {
    case Rock = "Rock"
    case Paper = "Paper"
    case Scissor = "Scissor"
    static func randomShape() -> Shape {
        let shapes = ["Rock", "Paper", "Scissor"]
        let randomChoice = Int(arc4random_uniform(3))
        return Shape(rawValue: shapes[randomChoice])!
    }
}

class ResultViewController: UIViewController {

    @IBOutlet weak var result: UIImageView!
    var userChoice: Shape!
    let computer = Shape.randomShape()

    @IBOutlet weak var label: UILabel!
    // create an variable to take output from play
    // create a outlet label to show what was play
    // create a random function for computer
    // create a outlet labe to show what computer player
    // show result using switch statement
    // show image 
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        displayResult()
    }
    
    func displayResult() {
        var imageName: String? = nil
        let matchup = "\(userChoice.rawValue) vs \(computer.rawValue)"
        switch (userChoice, computer) {
        //win
        case (.Paper, .Rock), (.Scissor, .Paper), (.Rock, .Scissor):
            label.text = "you won " + matchup
            imageName = "\(userChoice.rawValue)-\(computer.rawValue)"
        //lose
        case (.Rock, .Paper), (.Paper, .Scissor), (.Scissor, .Rock):
            label.text = "you lost " + matchup
            imageName = "\(userChoice.rawValue)-\(computer.rawValue)"
        //tie
        default:
            label.text = matchup
            imageName = "tie"
        /*
        case (.Paper, .Rock), (.Rock, .Paper):
            label.text = matchup
            imageName = "PaperCoversRock"
        case (.Scissor, .Rock), (.Rock, .Scissor):
            label.text = matchup
            imageName = "RockCrushesScissors"
        case (.Scissor, .Paper), (.Paper, .Scissor):
            label.text = matchup
            imageName = "ScissorsCutPaper"
        default:
            label.text = matchup
            imageName = "tie"
            */
        }
        if let imageName = imageName {
            print(imageName)
            result.image = UIImage(named: imageName.lowercased())
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
