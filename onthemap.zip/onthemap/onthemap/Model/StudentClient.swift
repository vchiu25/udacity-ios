//
//  StudentClient.swift
//  onthemap
//
//  Created by Vincent Chiu on 4/11/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import Foundation

func postStudentLocation(locationRequest: StudentLocationRequest, completion: @escaping (Bool, Error?)->Void) {
    var request = URLRequest(url: SessionManager.Endpoints.student.url)
    request.httpMethod = "POST"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    let encoder = JSONEncoder()
    request.httpBody = try! encoder.encode(locationRequest)
    let session = URLSession.shared
    let task = session.dataTask(with: request) { data, response, error in
      if error != nil { // Handle error…
          return
      }
      print(String(data: data!, encoding: .utf8)!)
    }
    task.resume()
}

func getStudentLocation(completion: @escaping (Bool, Error?)->Void) {
    let request = URLRequest(url: SessionManager.Endpoints.student.url)
    let task = URLSession.shared.dataTask(with: request) { data, response, error in
      if error != nil { // Handle error...
        print("unable to get data")
        return
      }
      //print(String(data: data!, encoding: .utf8)!)
      do {
        let decoder = JSONDecoder()
        let responseObject = try decoder.decode(StudentLocationResponse.self, from: data!)
        SessionManager.shared.locations = responseObject.results
        DispatchQueue.main.async {
          completion(true, nil)
        }
      } catch {
        completion(false, error)
        return
      }
    }
    task.resume()
}
