//
//  CollectionViewController.swift
//  VirtualTourist
//
//  Created by Vincent Chiu on 5/10/20.
//  Copyright © 2020 Vincent. All rights reserved.
//

import UIKit
import CoreData

class CollectionViewController: UIViewController, UICollectionViewDelegate {

  var dataController: DataController!
  var lat: Double=22.755717647786838
  var lon: Double=121.11699482549619
  var pin: Pin!

  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
    pin = findPin()
    if (fileExist(pin: pin)) {
      //load picture
    } else {
      //fetch picture
    }
  }

  @IBOutlet weak var image: UIImageView!

  // check to see if pictures already exist

  func findPin() -> Pin? {
    let fetchRequest: NSFetchRequest<Pin> = Pin.fetchRequest()
    fetchRequest.sortDescriptors = [NSSortDescriptor(key: "lat", ascending: true)]
    fetchRequest.predicate = NSPredicate(format: "lat == %@ AND lon == %@", lat, lon)
    if let result = try? dataController.viewContext.fetch(fetchRequest) {
      return result.first
    } else {
      return nil
    }
  }

  func fileExist(pin: Pin) -> Bool {
    if (pin.photo != nil) {
      return true
    } else {
      return false
    }
  }

  func fetchPicture() {
    FlickrClient.getSearchResult(lat: lat, lon: lon) { (data, error) in
      if error != nil {
        print(error!)
        return
      }
      print(data)
    }
  }

  func savePictures(list: [Data]) {
    for data in list {
      let photo = PhotoFile(context: dataController.viewContext)
      photo.photo = data
      try? dataController.viewContext.save()
    }
  }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

  func downloadPicture(url: String){
    let task = URLSession.shared.dataTask(with: URL(string: url)!) { (data, response, error) in
      if error != nil {
        //handle error
        return
      }
      DispatchQueue.main.async {
        self.image.image = UIImage(data: data!)
      }
    }
    task.resume()
  }
}
